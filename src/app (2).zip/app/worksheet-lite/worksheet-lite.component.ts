import {
  Component,
  OnInit,
  AfterViewInit,
  HostListener
} from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {
  WorksheetLiteService,
  PageItem
} from './worksheet-lite.service';
import { ChartItem } from './chart-gen.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  /* ================= SIDEBAR ================= */
  isSidebarCollapsed = false;

  /* ================= FILE UPLOAD ================= */
  uploadProgress = 0;
  uploadedData: any[] = [];

  /* ================= WORKFLOW ================= */
  defaultWorkflowFields: string[] = [];
  isCustomDataUploaded = false;

  /* ================= PROPERTY PANEL ================= */
  propertyPanelOpen = false;
  selectedItem: ChartItem | null = null;
  editableItem: ChartItem | null = null;
  originalSnapshot: ChartItem | null = null;

  pages: PageItem[] = [];
  pageTableFields: string[] = [];

  /* ================= X / Y FIELD UI STATE ================= */
  filteredFields: any[] = [];

  xFieldDisplayValue: string = '';
  yFieldDisplayValue: string = '';
  isXYEnabled = false;   // 🔥 initially disabled
  chartRequirements: any = null;


  constructor(public service: WorksheetLiteService,
    private snackBar: MatSnackBar
  ) { }

  /* ================= INIT ================= */
  ngOnInit(): void {
    this.service.loadCharts();
    this.service.loadWorkflow();

    this.service.workflowFields$.subscribe(fields => {
      this.defaultWorkflowFields = fields;
    });

    // 🔥 Real-time Data Sync
    this.service.fields$.subscribe(fields => {
      if (fields.length > 0) {
        this.updateChartsWithNewData();
      }
    });

    // 🔥 pages.json → keys only
    this.service.pages$.subscribe(pages => {
      this.pages = pages || []; // 🔥 Store for local usage
      if (pages && pages.length > 0) {

        // 🔥 extract table_name values
        this.pageTableFields = pages
          .map(p => p.table_name)
          .filter((v, i, a) => a.indexOf(v) === i); // unique

        console.log('Table Names:', this.pageTableFields);
      } else {
        this.pageTableFields = [];
      }
    });
  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    if (canvas) {
      this.service.initCanvas(canvas);
    }
  }

  /* ================= CANVAS ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {

    // 🔥 existing service drop logic (unchanged)
    this.service.dropOnCanvas(event);

    // 🔥 last dropped chart
    const lastChart =
      this.service.canvasCharts[this.service.canvasCharts.length - 1];

    // 🔥 open property panel immediately
    if (lastChart) {
      this.refreshGraph(lastChart);
      this.openPropertyPanel(lastChart);
    }
  }

  startMove(event: MouseEvent, index: number): void {
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    this.service.moveItem(event);
  }

  @HostListener('document:mouseup')
  stopMove(): void {
    this.service.stopMove();
  }

  /* ================= PROPERTY PANEL ================= */
  checkOverlapLive(item: ChartItem): void {
    if (!item) return;

    // Find the index of this chart in the canvasCharts array
    const index = this.service.canvasCharts.findIndex(c => c.id === item.id);
    if (index === -1) return;

    // Call the service method to adjust position if overlapping
    const [newX, newY] = this.service.findFreePosition(
      item.x ?? 0,
      item.y ?? 0,
      item.width ?? 0,
      item.height ?? 0,
      index
    );

    item.x = newX;
    item.y = newY;
  }
  onTableSelect(tableValue: string): void {
    const tableId = +tableValue;

    if (!this.editableItem || !tableId) return;

    const page = this.pages.find(p => p.id == tableId);
    if (!page) return;

    this.editableItem.tableId = +page.id;
    this.editableItem.tableName = page.table_name;

    // Filter data for this table
    const tableData = this.service.allFields.filter(
      f => f.page_id == page.id
    );
    this.editableItem.data = tableData;

    // Use keys of the first record as field options (Schema Keys)
    if (tableData.length > 0) {
      this.editableItem.fields = Object.keys(tableData[0]);
    } else {
      this.editableItem.fields = [];
    }

    // ✅ ENABLE HERE
    this.editableItem.isXYEnabled = true;

    this.editableItem.xField = '';
    this.editableItem.yField = '';

    // 🔥 Load requirements
    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);

    this.refreshGraph(this.editableItem, true);
  }

  onXFieldChange(fieldName: string) {
    if (!this.editableItem) return;
    this.editableItem.xField = fieldName;
    this.xFieldDisplayValue = fieldName;

    // Check for null/empty values
    if (fieldName && this.editableItem.data) {
      const hasNull = this.editableItem.data.some((d: any) => d[fieldName] === null || d[fieldName] === undefined || d[fieldName] === '');
      if (hasNull) {
        this.snackBar.open(`${fieldName}  is contains null or empty values`, 'Close', { duration: 3000 });
      }
    }

    this.refreshGraph(this.editableItem, true); // 🔥 Auto resize on field change
  }

  onYFieldChange(fieldName: string) {
    if (!this.editableItem) return;
    this.editableItem.yField = fieldName;
    this.yFieldDisplayValue = fieldName;

    // Check for null/empty values
    if (fieldName && this.editableItem.data) {
      const hasNull = this.editableItem.data.some((d: any) => d[fieldName] === null || d[fieldName] === undefined || d[fieldName] === '');
      if (hasNull) {
        this.snackBar.open(`${fieldName} is contains null or empty values`, 'Close', { duration: 3000 });
      }
    }

    this.refreshGraph(this.editableItem, true); // 🔥 Auto resize on field change
  }

  /* ================= SIZE CHANGE HANDLER ================= */
  onSizeChange(): void {
    if (!this.editableItem) return;

    // Validate minimum dimensions
    const minWidth = 180;
    const minHeight = 140;

    if (this.editableItem.width! < minWidth) {
      this.editableItem.width = minWidth;
      this.snackBar.open(`Minimum width is ${minWidth}px`, 'OK', { duration: 2000 });
    }

    if (this.editableItem.height! < minHeight) {
      this.editableItem.height = minHeight;
      this.snackBar.open(`Minimum height is ${minHeight}px`, 'OK', { duration: 2000 });
    }

    // Validate maximum dimensions (canvas bounds)
    const canvas = this.service.canvasEl;
    if (canvas) {
      const maxWidth = canvas.clientWidth - (this.editableItem.x ?? 0);
      const maxHeight = canvas.clientHeight - (this.editableItem.y ?? 0);

      if (this.editableItem.width! > maxWidth) {
        this.editableItem.width = maxWidth;
        this.snackBar.open(`Maximum width at this position is ${maxWidth}px`, 'OK', { duration: 2000 });
      }

      if (this.editableItem.height! > maxHeight) {
        this.editableItem.height = maxHeight;
        this.snackBar.open(`Maximum height at this position is ${maxHeight}px`, 'OK', { duration: 2000 });
      }
    }
  }

  refreshGraph(item: ChartItem, autoResize: boolean = false): void {
    // 🔥 Reload requirements on refresh (handles type change)
    this.chartRequirements = this.service.getChartRequirements(item.type);

    // Suggestion for stacked charts
    if (item.type === 'stackedBar' || item.type === 'stackedColumn') {
      const isBar = item.type === 'stackedBar';
      const catLabel = isBar ? 'Category (Y)' : 'Category (X)';
      const groupLabel = isBar ? 'Group By (X)' : 'Group By (Y)';

      this.snackBar.open(
        `Tip: For ${item.type}, select "${catLabel}" and "${groupLabel}" for stacked data.`,
        'Got it',
        { duration: 4000, horizontalPosition: 'center', verticalPosition: 'top' }
      );
    }

    // item.realGraphSvg = this.service.generateDynamicGraph(item); // REMOVED
    if (autoResize) {
      this.autoResizeItem(item);
    }
  }

  autoResizeItem(item: ChartItem): void {
    if (!item.data || item.data.length === 0) {
      item.width = 180;
      item.height = 180;
      return;
    }

    if (!item.xField && !item.yField) {
      item.width = 180;
      item.height = 180;
      return;
    }

    // Determine dimension field based on chart type
    let dimField = '';
    if (item.type === 'bar' || item.type === 'stackedBar') dimField = item.yField || '';
    else dimField = item.xField || '';

    let categoriesCount = 0;
    if (dimField) {
      const uniqueVals = new Set(item.data.map(d => String(d[dimField] || 'N/A')));
      categoriesCount = Math.min(uniqueVals.size, 10); // Match service slice limit
    }

    if (item.type === 'column' || item.type === 'stackedColumn') {
      item.width = Math.max(400, categoriesCount * 60 + 100);
      item.height = 350;
    } else if (item.type === 'bar' || item.type === 'stackedBar') {
      item.width = 450;
      item.height = Math.max(300, categoriesCount * 50 + 100);
    } else {
      // Default Graph Size for others (Pie, Line, etc.)
      item.width = 400;
      item.height = 350;
    }
  }
  openPropertyPanel(chart: ChartItem): void {

    this.isCustomDataUploaded = false;
    this.isXYEnabled = false;

    this.selectedItem = chart;
    this.originalSnapshot = JSON.parse(JSON.stringify(chart));

    this.editableItem = {
      ...chart,
      x: Math.round(chart.x ?? 0),
      y: Math.round(chart.y ?? 0),
      width: Math.round(chart.width ?? 0),
      height: Math.round(chart.height ?? 0)
    };

    // 🔥 RESTORE STATE
    if (this.editableItem.data && this.editableItem.data.length > 0) {
      // Restore fields from existing data
      this.editableItem.fields = Object.keys(this.editableItem.data[0]);
      this.editableItem.isXYEnabled = true;

      // Restore display values
      this.xFieldDisplayValue = this.editableItem.xField || '';
      this.yFieldDisplayValue = this.editableItem.yField || '';

    } else if (this.editableItem.tableId) {
      // Restore from Table ID if data missing but ID exists
      const page = this.pages.find(p => p.id === this.editableItem!.tableId);
      if (page) {
        const tableData = this.service.allFields.filter(f => f.page_id == page.id);
        this.editableItem.data = tableData;

        if (tableData.length > 0) {
          this.editableItem.fields = Object.keys(tableData[0]);
        }
        this.editableItem.isXYEnabled = true;
        this.xFieldDisplayValue = this.editableItem.xField || '';
        this.yFieldDisplayValue = this.editableItem.yField || '';
      }
    } else {
      // First time or empty
      this.editableItem.fields = [];
      this.filteredFields = [];
      this.xFieldDisplayValue = '';
      this.yFieldDisplayValue = '';
    }

    this.editableItem.yField = this.editableItem.yField || '';

    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);

    this.propertyPanelOpen = true;
  }

  saveChanges(): void {
    if (!this.selectedItem || !this.editableItem) return;

    // 🔥 REFRESH ONE LAST TIME (SVG only, no resize)
    this.refreshGraph(this.editableItem, false);

    // ✅ RESPECT MANUAL INPUTS: Removed findFreePosition call here.
    // If user typed X/Y/W/H in property panel, we keep it.

    // Save all properties (including data, fields, xField, yField)

    // Save all properties (including data, fields, xField, yField)
    Object.assign(this.selectedItem, this.editableItem);
    this.cleanupPropertyPanel();
  }

  cancelChanges(): void {
    if (this.selectedItem && this.originalSnapshot) {
      Object.assign(this.selectedItem, this.originalSnapshot);
    }
    this.cleanupPropertyPanel();
  }

  cleanupPropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem = null;
    this.editableItem = null;
    this.originalSnapshot = null;
    this.uploadProgress = 0;
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) {
      this.cleanupPropertyPanel();
    }
  }

  /* ================= FILE UPLOAD ================= */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const file = input.files[0];
    this.uploadProgress = 0;

    this.service.uploadFile(file, p => {
      this.uploadProgress = p;
    })
      .then(data => {

        // 🔥 MAIN LOGIC
        this.isCustomDataUploaded = true;

        if (this.editableItem) {
          this.editableItem.data = data;
          this.setFieldsForSelectedChart(data);
          this.refreshGraph(this.editableItem, true);
        }

        // ✅ Set to 100 to trigger success animation
        this.uploadProgress = 100;

        // auto hide progress after animation
        setTimeout(() => {
          this.uploadProgress = 0;
        }, 2000);
      });
  }
  /* ================= FIELD EXTRACTION ================= */
  setFieldsForSelectedChart(data: any[]): void {
    if (!data || data.length === 0 || !this.editableItem) return;

    const fields = Object.keys(data[0]);

    this.editableItem.fields = fields;

    // reset selections
    this.editableItem.valueField = '';
    this.editableItem.xField = '';
    this.editableItem.yField = '';
  }

  /* ================= SIDEBAR ================= */
  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  /* ================= UPDATE CHARTS WITH NEW DATA ================= */
  updateChartsWithNewData() {
    this.service.canvasCharts.forEach(chart => {
      if (chart.tableId) {
        // Re-fetch data for this chart's tableId
        const pageIdStr = String(chart.tableId);
        const newData = this.service.getFieldsByPageId(pageIdStr);

        if (newData && newData.length > 0) {
          chart.data = newData;
          this.refreshGraph(chart, false); // Refresh without changing layout
        }
      }
    });

    // Also update the property panel item if open
    if (this.propertyPanelOpen && this.selectedItem && this.editableItem) {
      if (this.selectedItem.tableId) {
        const pageIdStr = String(this.selectedItem.tableId);
        const newData = this.service.getFieldsByPageId(pageIdStr);
        if (newData && newData.length > 0) {
          this.editableItem.data = newData;
          this.refreshGraph(this.editableItem, false);
        }
      }
    }
  }
}
