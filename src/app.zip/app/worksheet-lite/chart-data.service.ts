import { Injectable } from '@angular/core';
import { FieldData } from './worksheet-lite.service';

export interface ChartConfig {
  type: string;
  data: any;
  options: any;
}

@Injectable({
  providedIn: 'root'
})
export class ChartDataService {

  // Main method that routes to the correct chart generation method based on chart type
  generateChartFromFields(
    filteredFields: FieldData[],  
    xField: string,              
    yField: string,
    chartType: string,
    yField2?: string,
    yField3?: string
  ): ChartConfig {
    
    console.log(`📊 Generating ${chartType.toUpperCase()} CHART from field data:`, {
      recordCount: filteredFields.length,
      xAxis: xField,
      yAxis: yField,
      yAxis2: yField2,
      yAxis3: yField3,
      type: chartType
    });

    // Route to appropriate chart generator based on type
    switch(chartType) {
      case 'line':
        return this.generateLineChart(filteredFields, xField, yField);
      case 'area':
        return this.generateAreaChart(filteredFields, xField, yField);
      case 'stacked-area':
        return this.generateStackedAreaChart(filteredFields, xField, yField, yField2, yField3);
      default:
        // Fallback to line chart
        return this.generateLineChart(filteredFields, xField, yField);
    }
  }

  // ================= LINE CHART =================
  private generateLineChart(
    filteredFields: FieldData[],
    xField: string,
    yField: string
  ): ChartConfig {
    if (xField === 'createddate' || xField === 'lastmodifieddate') {
      return this.createDateLineChart(filteredFields, xField, yField);
    } else {
      return this.createCategoryLineChart(filteredFields, xField, yField);
    }
  }

  // ================= AREA CHART =================
  private generateAreaChart(
    filteredFields: FieldData[],
    xField: string,
    yField: string
  ): ChartConfig {
    if (xField === 'createddate' || xField === 'lastmodifieddate') {
      return this.createDateAreaChart(filteredFields, xField, yField);
    } else {
      return this.createCategoryAreaChart(filteredFields, xField, yField);
    }
  }

  // ================= STACKED AREA CHART =================
  private generateStackedAreaChart(
    filteredFields: FieldData[],
    xField: string,
    yField: string,
    yField2?: string,
    yField3?: string
  ): ChartConfig {
    if (xField === 'createddate' || xField === 'lastmodifieddate') {
      return this.createDateStackedAreaChart(filteredFields, xField, yField, yField2, yField3);
    } else {
      return this.createCategoryStackedAreaChart(filteredFields, xField, yField, yField2, yField3);
    }
  }

  // ================= DATE LINE CHART =================
  private createDateLineChart(
    fields: FieldData[],
    xField: string,
    yField: string
  ): ChartConfig {
    
    const groupedData: { [key: string]: FieldData[] } = {};
    
    fields.forEach(record => {
      let dateValue = record[xField];
      if (dateValue && typeof dateValue === 'string') {
        dateValue = dateValue.split(' ')[0];
      }
      const key = dateValue || 'Unknown';
      
      if (!groupedData[key]) {
        groupedData[key] = [];
      }
      groupedData[key].push(record);
    });
    
    const sortedDates = Object.keys(groupedData).sort();
    
    let chartData: number[] = [];
    
    if (yField === 'id') {
      chartData = sortedDates.map(date => groupedData[date].length);
    } else {
      chartData = sortedDates.map(date => {
        const records = groupedData[date];
        const total = records.reduce((sum, record) => {
          const val = record[yField];
          if (typeof val === 'number') return sum + val;
          if (typeof val === 'string') {
            const num = parseFloat(val);
            return sum + (isNaN(num) ? 0 : num);
          }
          return sum;
        }, 0);
        return total;
      });
    }
    
    const labels = sortedDates.map(date => {
      if (date.includes('-')) {
        const parts = date.split('-');
        return `${parts[1]}/${parts[2]}`;
      }
      return date;
    });
    
    return {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: yField, 
          data: chartData,
          borderColor: 'rgb(25, 118, 210)',
          backgroundColor: 'rgba(25, 118, 210, 0.1)',
          borderWidth: 2,
          tension: 0.3,
          fill: true,
          pointBackgroundColor: 'rgb(25, 118, 210)',
          pointBorderColor: 'white',
          pointBorderWidth: 1,
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: `Line Chart: Fields by ${this.formatTitle(xField)}`,  
            font: {
              size: 13,
              weight: 'bold'
            },
            padding: {
              top: 10,
              bottom: 15
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 11
              }
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleFont: {
              size: 12
            },
            bodyFont: {
              size: 11
            }
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: xField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 10
              },
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            title: {
              display: true,
              text: yField,  
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 10
              }
            }
          }
        }
      }
    };
  }

  // ================= CATEGORY LINE CHART =================
  private createCategoryLineChart(
    fields: FieldData[],
    xField: string,
    yField: string
  ): ChartConfig {
    
    const groupedData: { [key: string]: FieldData[] } = {};
    
    fields.forEach(record => {
      const key = String(record[xField] || 'Unknown');
      if (!groupedData[key]) {
        groupedData[key] = [];
      }
      groupedData[key].push(record);
    });
    
    const categories = Object.keys(groupedData).sort();
    
    let chartData: number[] = [];
    
    if (yField === 'id') {
      chartData = categories.map(cat => groupedData[cat].length);
    } else {
      chartData = categories.map(cat => {
        const records = groupedData[cat];
        const total = records.reduce((sum, record) => {
          const val = record[yField];
          if (typeof val === 'number') return sum + val;
          if (typeof val === 'string') {
            const num = parseFloat(val);
            return sum + (isNaN(num) ? 0 : num);
          }
          return sum;
        }, 0);
        return total;
      });
    }
    
    return {
      type: 'line',
      data: {
        labels: categories,
        datasets: [{
          label: yField, 
          data: chartData,
          borderColor: 'rgb(25, 118, 210)',
          backgroundColor: 'rgba(25, 118, 210, 0.1)',
          borderWidth: 2,
          tension: 0.1,
          // fill: true,
          pointBackgroundColor: 'rgb(25, 118, 210)',
          pointBorderColor: 'white',
          pointBorderWidth: 1,
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: `Line Chart: Fields by ${this.formatTitle(xField)}`,  
            font: {
              size: 13,
              weight: 'bold'
            },
            padding: {
              top: 10,
              bottom: 15
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 11
              }
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleFont: {
              size: 12
            },
            bodyFont: {
              size: 11
            }
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: xField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 10
              },
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            title: {
              display: true,
              text: yField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 10
              }
            }
          }
        }
      }
    };
  }

  // ================= DATE AREA CHART =================
  private createDateAreaChart(
    fields: FieldData[],
    xField: string,
    yField: string
  ): ChartConfig {
    
    const groupedData: { [key: string]: FieldData[] } = {};
    
    fields.forEach(record => {
      let dateValue = record[xField];
      if (dateValue && typeof dateValue === 'string') {
        dateValue = dateValue.split(' ')[0];
      }
      const key = dateValue || 'Unknown';
      
      if (!groupedData[key]) {
        groupedData[key] = [];
      }
      groupedData[key].push(record);
    });
    
    const sortedDates = Object.keys(groupedData).sort();
    
    let chartData: number[] = [];
    
    if (yField === 'id') {
      chartData = sortedDates.map(date => groupedData[date].length);
    } else {
      chartData = sortedDates.map(date => {
        const records = groupedData[date];
        const total = records.reduce((sum, record) => {
          const val = record[yField];
          if (typeof val === 'number') return sum + val;
          if (typeof val === 'string') {
            const num = parseFloat(val);
            return sum + (isNaN(num) ? 0 : num);
          }
          return sum;
        }, 0);
        return total;
      });
    }
    
    const labels = sortedDates.map(date => {
      if (date.includes('-')) {
        const parts = date.split('-');
        return `${parts[1]}/${parts[2]}`;
      }
      return date;
    });
    
    return {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: yField, 
          data: chartData,
          borderColor: 'rgb(76, 175, 80)',
          backgroundColor: 'rgba(76, 175, 80, 0.4)',
          borderWidth: 2,
          tension: 0.4,
          fill: true,
          pointBackgroundColor: 'rgb(76, 175, 80)',
          pointBorderColor: 'white',
          pointBorderWidth: 1,
          pointRadius: 3,
          pointHoverRadius: 5
        }]
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: `Area Chart: Fields by ${this.formatTitle(xField)}`,  
            font: {
              size: 13,
              weight: 'bold'
            },
            padding: {
              top: 10,
              bottom: 15
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 11
              }
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleFont: {
              size: 12
            },
            bodyFont: {
              size: 11
            }
          },
          filler: {
            propagate: true
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: xField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 10
              },
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            title: {
              display: true,
              text: yField,  
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 10
              }
            }
          }
        }
      }
    };
  }

  // ================= CATEGORY AREA CHART =================
  private createCategoryAreaChart(
    fields: FieldData[],
    xField: string,
    yField: string
  ): ChartConfig {
    
    const groupedData: { [key: string]: FieldData[] } = {};
    
    fields.forEach(record => {
      const key = String(record[xField] || 'Unknown');
      if (!groupedData[key]) {
        groupedData[key] = [];
      }
      groupedData[key].push(record);
    });
    
    const categories = Object.keys(groupedData).sort();
    
    let chartData: number[] = [];
    
    if (yField === 'id') {
      chartData = categories.map(cat => groupedData[cat].length);
    } else {
      chartData = categories.map(cat => {
        const records = groupedData[cat];
        const total = records.reduce((sum, record) => {
          const val = record[yField];
          if (typeof val === 'number') return sum + val;
          if (typeof val === 'string') {
            const num = parseFloat(val);
            return sum + (isNaN(num) ? 0 : num);
          }
          return sum;
        }, 0);
        return total;
      });
    }
    
    return {
      type: 'line',
      data: {
        labels: categories,
        datasets: [{
          label: yField, 
          data: chartData,
          borderColor: 'rgb(76, 175, 80)',
          backgroundColor: 'rgba(76, 175, 80, 0.4)',
          borderWidth: 2,
          tension: 0.4,
          fill: true,
          pointBackgroundColor: 'rgb(76, 175, 80)',
          pointBorderColor: 'white',
          pointBorderWidth: 1,
          pointRadius: 3,
          pointHoverRadius: 5
        }]
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: true,
            text: `Area Chart: Fields by ${this.formatTitle(xField)}`,  
            font: {
              size: 13,
              weight: 'bold'
            },
            padding: {
              top: 10,
              bottom: 15
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 11
              }
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleFont: {
              size: 12
            },
            bodyFont: {
              size: 11
            }
          },
          filler: {
            propagate: true
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: xField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 10
              },
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            title: {
              display: true,
              text: yField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 10
              }
            }
          }
        }
      }
    };
  }

  // ================= DATE STACKED AREA CHART =================
  private createDateStackedAreaChart(
    fields: FieldData[],
    xField: string,
    yField: string,
    yField2?: string,
    yField3?: string
  ): ChartConfig {
    
    const groupedData: { [key: string]: FieldData[] } = {};
    
    fields.forEach(record => {
      let dateValue = record[xField];
      if (dateValue && typeof dateValue === 'string') {
        dateValue = dateValue.split(' ')[0];
      }
      const key = dateValue || 'Unknown';
      
      if (!groupedData[key]) {
        groupedData[key] = [];
      }
      groupedData[key].push(record);
    });
    
    const sortedDates = Object.keys(groupedData).sort();
    
    const labels = sortedDates.map(date => {
      if (date.includes('-')) {
        const parts = date.split('-');
        return `${parts[1]}/${parts[2]}`;
      }
      return date;
    });

    // Helper function to calculate data for a field
    const calculateDataForField = (fieldName: string): number[] => {
      if (fieldName === 'id') {
        return sortedDates.map(date => groupedData[date].length);
      } else {
        return sortedDates.map(date => {
          const records = groupedData[date];
          const total = records.reduce((sum, record) => {
            const val = record[fieldName];
            if (typeof val === 'number') return sum + val;
            if (typeof val === 'string') {
              const num = parseFloat(val);
              return sum + (isNaN(num) ? 0 : num);
            }
            return sum;
          }, 0);
          return total;
        });
      }
    };

    // Create datasets based on which Y fields are provided
    const datasets: any[] = [];
    const colors = [
      { border: 'rgb(25, 118, 210)', background: 'rgba(25, 118, 210, 0.6)' },
      { border: 'rgb(76, 175, 80)', background: 'rgba(76, 175, 80, 0.6)' },
      { border: 'rgb(255, 152, 0)', background: 'rgba(255, 152, 0, 0.6)' }
    ];

    // Add Y1 dataset
    datasets.push({
      label: yField,
      data: calculateDataForField(yField),
      borderColor: colors[0].border,
      backgroundColor: colors[0].background,
      borderWidth: 2,
      tension: 0.4,
      fill: true,
      pointBackgroundColor: colors[0].border,
      pointBorderColor: 'white',
      pointBorderWidth: 1,
      pointRadius: 2,
      pointHoverRadius: 4
    });

    // Add Y2 dataset if provided
    if (yField2) {
      datasets.push({
        label: yField2,
        data: calculateDataForField(yField2),
        borderColor: colors[1].border,
        backgroundColor: colors[1].background,
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: colors[1].border,
        pointBorderColor: 'white',
        pointBorderWidth: 1,
        pointRadius: 2,
        pointHoverRadius: 4
      });
    }

    // Add Y3 dataset if provided
    if (yField3) {
      datasets.push({
        label: yField3,
        data: calculateDataForField(yField3),
        borderColor: colors[2].border,
        backgroundColor: colors[2].background,
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: colors[2].border,
        pointBorderColor: 'white',
        pointBorderWidth: 1,
        pointRadius: 2,
        pointHoverRadius: 4
      });
    }
    
    return {
      type: 'line',
      data: {
        labels: labels,
        datasets: datasets
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          title: {
            display: true,
            text: `Stacked Area Chart: Fields by ${this.formatTitle(xField)}`,  
            font: {
              size: 13,
              weight: 'bold'
            },
            padding: {
              top: 10,
              bottom: 15
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 10
              },
              usePointStyle: true,
              boxWidth: 10,
              padding: 8
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleFont: {
              size: 12
            },
            bodyFont: {
              size: 11
            },
            mode: 'index',
            intersect: false
          },
          filler: {
            propagate: true
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: xField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 10
              },
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            stacked: true,
            title: {
              display: true,
              text: 'Values',  
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 10
              }
            }
          }
        }
      }
    };
  }

  // ================= CATEGORY STACKED AREA CHART =================
  private createCategoryStackedAreaChart(
    fields: FieldData[],
    xField: string,
    yField: string,
    yField2?: string,
    yField3?: string
  ): ChartConfig {
    
    const groupedData: { [key: string]: FieldData[] } = {};
    
    fields.forEach(record => {
      const key = String(record[xField] || 'Unknown');
      if (!groupedData[key]) {
        groupedData[key] = [];
      }
      groupedData[key].push(record);
    });
    
    const categories = Object.keys(groupedData).sort();

    // Helper function to calculate data for a field
    const calculateDataForField = (fieldName: string): number[] => {
      if (fieldName === 'id') {
        return categories.map(cat => groupedData[cat].length);
      } else {
        return categories.map(cat => {
          const records = groupedData[cat];
          const total = records.reduce((sum, record) => {
            const val = record[fieldName];
            if (typeof val === 'number') return sum + val;
            if (typeof val === 'string') {
              const num = parseFloat(val);
              return sum + (isNaN(num) ? 0 : num);
            }
            return sum;
          }, 0);
          return total;
        });
      }
    };

    // Create datasets based on which Y fields are provided
    const datasets: any[] = [];
    const colors = [
      { border: 'rgb(25, 118, 210)', background: 'rgba(25, 118, 210, 0.6)' },
      { border: 'rgb(76, 175, 80)', background: 'rgba(76, 175, 80, 0.6)' },
      { border: 'rgb(255, 152, 0)', background: 'rgba(255, 152, 0, 0.6)' }
    ];

    // Add Y1 dataset
    datasets.push({
      label: yField,
      data: calculateDataForField(yField),
      borderColor: colors[0].border,
      backgroundColor: colors[0].background,
      borderWidth: 2,
      tension: 0.4,
      fill: true,
      pointBackgroundColor: colors[0].border,
      pointBorderColor: 'white',
      pointBorderWidth: 1,
      pointRadius: 2,
      pointHoverRadius: 4
    });

    // Add Y2 dataset if provided
    if (yField2) {
      datasets.push({
        label: yField2,
        data: calculateDataForField(yField2),
        borderColor: colors[1].border,
        backgroundColor: colors[1].background,
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: colors[1].border,
        pointBorderColor: 'white',
        pointBorderWidth: 1,
        pointRadius: 2,
        pointHoverRadius: 4
      });
    }

    // Add Y3 dataset if provided
    if (yField3) {
      datasets.push({
        label: yField3,
        data: calculateDataForField(yField3),
        borderColor: colors[2].border,
        backgroundColor: colors[2].background,
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointBackgroundColor: colors[2].border,
        pointBorderColor: 'white',
        pointBorderWidth: 1,
        pointRadius: 2,
        pointHoverRadius: 4
      });
    }
    
    return {
      type: 'line',
      data: {
        labels: categories,
        datasets: datasets
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          title: {
            display: true,
            text: `Stacked Area Chart: Fields by ${this.formatTitle(xField)}`,  
            font: {
              size: 13,
              weight: 'bold'
            },
            padding: {
              top: 10,
              bottom: 15
            }
          },
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                size: 10
              },
              usePointStyle: true,
              boxWidth: 10,
              padding: 8
            }
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            titleFont: {
              size: 12
            },
            bodyFont: {
              size: 11
            },
            mode: 'index',
            intersect: false
          },
          filler: {
            propagate: true
          }
        },
        scales: {
          x: {
            title: {
              display: true,
              text: xField, 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 10
              },
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            stacked: true,
            title: {
              display: true,
              text: 'Values', 
              font: {
                size: 11,
                weight: 'normal'
              }
            },
            beginAtZero: true,
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 10
              }
            }
          }
        }
      }
    };
  }

  private formatTitle(field: string): string {
    const titles: { [key: string]: string } = {
      'id': 'Record ID',
      'column_name': 'Column Name',
      'property_name': 'Property Name',
      'createdby': 'Created By',
      'createddate': 'Creation Date',
      'lastmodifiedby': 'Last Modified By',
      'lastmodifieddate': 'Last Modified Date',
      'logical_module_id': 'Module',
      'page_id': 'Page',
      'project_id': 'Project',
      'hide': 'Hidden Status',
      'profile_view': 'Profile View'
    };
    return titles[field] || field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }
}