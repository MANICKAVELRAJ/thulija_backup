import {
  Component,
  AfterViewInit,
  OnInit,
  HostListener,
  ChangeDetectorRef
} from '@angular/core';

import { CdkDragDrop } from '@angular/cdk/drag-drop';
import {
  WorksheetLiteService,
  ChartItem,
  PageData,
  FieldData,
  KeyName
} from './worksheet-lite.service';

import { ChartDataService } from './chart-data.service';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  isSidebarCollapsed = false;

  propertyPanelOpen      = false;
  selectedItem: ChartItem | null = null;
  tempItem: ChartItem     | null = null;
  originalItemValues: any = null;
  hasChanges             = false;
  showConfirmationDialog = false;
  isOverlapping          = false;

  /* ================= RESIZE FUNCTIONALITY ================= */
  selectedChartId: number | null = null;
  isResizing = false;
  resizingChart: ChartItem | null = null;
  resizeDirection: string = '';
  resizeStartX = 0;
  resizeStartY = 0;
  resizeStartWidth = 0;
  resizeStartHeight = 0;
  resizeStartLeft = 0;
  resizeStartTop = 0;

  availablePages: PageData[]     = [];
  availableFields: FieldData[]   = [];
  availableLogicalModules: string[] = [];
  availableFieldKeys: string[]   = [];
  availableFieldNames: KeyName[] = [];
  hasFieldsForSelectedPage       = false;
  isLoadingData                  = true;

  private readonly SPECIFIC_FIELDS = [
    'id',
    'project_id',
    'logical_module_id',
    'page_id',
    'column_name',
    'property_name',
    'hide',
    'profile_view',
    'createdby',
    'createddate',
    'lastmodifiedby',
    'lastmodifieddate'
  ];

  canvasWidth  = 1200;
  canvasHeight = 800;

  constructor(
    public service: WorksheetLiteService,
    private cdRef: ChangeDetectorRef,
    private chartDataService: ChartDataService
  ) {}

  ngOnInit(): void {
    this.updateCanvasSize();
    this.loadPagesAndFields();
  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    this.service.initCanvas(canvas, this);
  }

  loadPagesAndFields(): void {
    this.isLoadingData = true;

    this.service.loadPagesAndFields().subscribe({
      next: (data) => {
        this.availablePages  = data.pages;
        this.availableFields = data.fields;
        this.availableLogicalModules = this.extractLogicalModules(this.availablePages);

        console.log('✅ Loaded pages:', this.availablePages.length);
        console.log('✅ Loaded fields:', this.availableFields.length);
        console.log('✅ Logical modules found:', this.availableLogicalModules);

        this.isLoadingData = false;
        this.cdRef.detectChanges();
      },
      error: (error) => {
        console.error('❌ Error loading JSON data:', error);
        this.availablePages          = [];
        this.availableFields         = [];
        this.availableLogicalModules = [];
        this.isLoadingData           = false;
        this.cdRef.detectChanges();
      }
    });
  }

  private extractLogicalModules(pages: PageData[]): string[] {
    const moduleSet = new Set<string>();
    pages.forEach(page => {
      if (page.logical_module_id) {
        moduleSet.add(page.logical_module_id);
      }
    });
    return Array.from(moduleSet).sort((a, b) => parseInt(a) - parseInt(b));
  }

  onPageSelectionChange(selectedModuleId: string): void {
    if (!this.tempItem) return;

    this.tempItem.pageId   = selectedModuleId;
    this.tempItem.fieldXId = '';
    this.tempItem.fieldYId = '';
    this.tempItem.fieldY2Id = '';
    this.tempItem.fieldY3Id = '';

    this.updateAvailableFieldKeys(selectedModuleId);
    this.updateChartInRealTime();
  }

  private updateAvailableFieldKeys(logicalModuleId: string): void {
    if (!logicalModuleId) {
      this.availableFieldKeys       = [];
      this.availableFieldNames      = [];
      this.hasFieldsForSelectedPage = false;
      return;
    }

    const moduleFields = this.availableFields.filter(
      field => field.logical_module_id === logicalModuleId
    );

    console.log(`=== Module ${logicalModuleId}: ${moduleFields.length} records ===`);

    if (moduleFields.length === 0) {
      this.availableFieldKeys       = [];
      this.availableFieldNames      = [];
      this.hasFieldsForSelectedPage = false;
      return;
    }

    const validFieldNames: KeyName[] = [];

    this.SPECIFIC_FIELDS.forEach(fieldKey => {
      let hasAnyNonNullValue = false;
      let hasAnyNullValue    = false;
      let nonNullCount       = 0;
      const totalCount       = moduleFields.length;

      moduleFields.forEach(field => {
        if (this.isNullValue(field[fieldKey])) {
          hasAnyNullValue = true;
        } else {
          hasAnyNonNullValue = true;
          nonNullCount++;
        }
      });

      if (hasAnyNonNullValue) {
        validFieldNames.push({
          key: fieldKey,
          displayName: this.formatKeyName(fieldKey)
        });
        console.log(`✅ "${fieldKey}": ${nonNullCount}/${totalCount} non-null`
          + (hasAnyNullValue ? ' (partial)' : ' (100%)'));
      } else {
        console.log(`❌ "${fieldKey}": all null`);
      }
    });

    validFieldNames.sort((a, b) => a.displayName.localeCompare(b.displayName));

    this.availableFieldNames      = validFieldNames;
    this.availableFieldKeys       = validFieldNames.map(f => f.key);
    this.hasFieldsForSelectedPage = this.availableFieldKeys.length > 0;

    console.log(`Fields available: ${this.availableFieldNames.map(f => f.key).join(', ')}`);
  }

  private generateChartConfig(item: ChartItem): void {
    // For stacked area chart, require at least one Y field (can have 1-3)
    if (item.type === 'stacked-area') {
      if (!item.pageId || !item.fieldXId || !item.fieldYId) {
        item.chartConfig = undefined;
        console.log('⚠️ Stacked area chart generation skipped: missing required selections');
        return;
      }
    } else {
      // For line and area charts, require X and Y
      if (!item.pageId || !item.fieldXId || !item.fieldYId) {
        item.chartConfig = undefined;
        console.log('⚠️ Chart generation skipped: missing selections');
        return;
      }
    }

    const filteredFields = this.availableFields.filter(
      field => field.logical_module_id === item.pageId
    );

    if (filteredFields.length === 0) {
      console.warn(`⚠️ No fields found for module ${item.pageId}`);
      item.chartConfig = undefined;
      return;
    }

    console.log(`📊 Generating chart for module ${item.pageId}:`, {
      records: filteredFields.length,
      xField: item.fieldXId,
      yField: item.fieldYId,
      y2Field: item.fieldY2Id,
      y3Field: item.fieldY3Id,
      chartType: item.type
    });

    // Pass the chart type and all Y fields to generate the appropriate chart
    const chartConfig = this.chartDataService.generateChartFromFields(
      filteredFields,
      item.fieldXId,
      item.fieldYId,
      item.type || 'line',
      item.fieldY2Id,
      item.fieldY3Id
    );

    item.chartConfig = chartConfig;
    console.log('✅ Chart config generated');
  }

  private isNullValue(value: any): boolean {
    return value === null || 
           value === undefined || 
           value === '' || 
           (typeof value === 'string' && value.trim() === '');
  }

  private formatKeyName(key: string): string {
    const nameMap: { [key: string]: string } = {
      'id': 'Record ID',
      'project_id': 'Project ID',
      'logical_module_id': 'Module ID',
      'page_id': 'Page ID',
      'column_name': 'Column Name',
      'property_name': 'Property Name',
      'hide': 'Hidden Status',
      'profile_view': 'Profile View',
      'createdby': 'Created By',
      'createddate': 'Creation Date',
      'lastmodifiedby': 'Last Modified By',
      'lastmodifieddate': 'Last Modified Date'
    };
    return nameMap[key] || key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }

  getFieldDisplayName(fieldKey: string): string {
    const field = this.availableFieldNames.find(f => f.key === fieldKey);
    return field ? field.displayName : fieldKey;
  }

  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
    setTimeout(() => this.updateCanvasSize(), 10);
  }

  startMove(event: MouseEvent, index: number): void {
    // Don't start move if we're resizing
    if (this.isResizing) {
      event.stopPropagation();
      return;
    }
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    // Handle resize if in resize mode
    if (this.isResizing && this.resizingChart) {
      this.handleResize(event);
      // Expand canvas concurrently during resize
      this.expandCanvasDuringResize();
      return;
    }

    // Handle move
    this.service.moveItem(event);

    // Expand canvas concurrently during move
    if (this.service.movingIndex !== null) {
      const chart       = this.service.canvasCharts[this.service.movingIndex];
      const chartRight  = (chart.x || 0) + (chart.width  || 180);
      const chartBottom = (chart.y || 0) + (chart.height || 140);

      // Expand canvas in real-time as chart moves near edges
      const expansionThreshold = 50;
      if (chartRight  + expansionThreshold > this.canvasWidth ||
          chartBottom + expansionThreshold > this.canvasHeight) {
        this.updateCanvasSize();
      }
    }
  }

  @HostListener('document:mouseup')
  stopMove(): void {
    // Stop resize if in resize mode
    if (this.isResizing) {
      this.stopResize();
      return;
    }

    // Stop move
    this.service.stopMove();
    setTimeout(() => this.updateCanvasSize(), 10);
  }

  /* ================= CHART SELECTION ================= */
  selectChart(chartId: number, event: MouseEvent): void {
    event.stopPropagation();
    this.selectedChartId = chartId;
  }

  /* ================= RESIZE FUNCTIONALITY ================= */
  startResize(event: MouseEvent, chart: ChartItem, direction: string): void {
    event.stopPropagation();
    event.preventDefault();

    this.isResizing = true;
    this.resizingChart = chart;
    this.resizeDirection = direction;
    
    // Get the worksheet canvas element to account for scroll position
    const worksheet = document.querySelector('.worksheet') as HTMLElement;
    const rect = worksheet ? worksheet.getBoundingClientRect() : null;
    
    // Store mouse position relative to the canvas, not viewport
    this.resizeStartX = rect ? event.clientX - rect.left + worksheet.scrollLeft : event.clientX;
    this.resizeStartY = rect ? event.clientY - rect.top + worksheet.scrollTop : event.clientY;
    
    // Store current chart dimensions and position
    this.resizeStartWidth = chart.width || 180;
    this.resizeStartHeight = chart.height || 140;
    this.resizeStartLeft = chart.x || 0;
    this.resizeStartTop = chart.y || 0;
  }

  handleResize(event: MouseEvent): void {
    if (!this.resizingChart) return;

    // Get the worksheet canvas element to account for scroll position
    const worksheet = document.querySelector('.worksheet') as HTMLElement;
    const rect = worksheet ? worksheet.getBoundingClientRect() : null;
    
    // Calculate current mouse position relative to canvas
    const currentX = rect ? event.clientX - rect.left + worksheet.scrollLeft : event.clientX;
    const currentY = rect ? event.clientY - rect.top + worksheet.scrollTop : event.clientY;
    
    // Calculate delta from start position
    const deltaX = currentX - this.resizeStartX;
    const deltaY = currentY - this.resizeStartY;

    let newWidth = this.resizeStartWidth;
    let newHeight = this.resizeStartHeight;
    let newX = this.resizeStartLeft;
    let newY = this.resizeStartTop;

    const minWidth = 120;
    const minHeight = 100;
    const maxWidth = 800;
    const maxHeight = 600;

    // Handle different resize directions
    switch (this.resizeDirection) {
      case 'se': // Southeast (bottom-right)
        newWidth = this.resizeStartWidth + deltaX;
        newHeight = this.resizeStartHeight + deltaY;
        break;

      case 'sw': // Southwest (bottom-left)
        newWidth = this.resizeStartWidth - deltaX;
        newHeight = this.resizeStartHeight + deltaY;
        newX = this.resizeStartLeft + deltaX;
        break;

      case 'ne': // Northeast (top-right)
        newWidth = this.resizeStartWidth + deltaX;
        newHeight = this.resizeStartHeight - deltaY;
        newY = this.resizeStartTop + deltaY;
        break;

      case 'nw': // Northwest (top-left)
        newWidth = this.resizeStartWidth - deltaX;
        newHeight = this.resizeStartHeight - deltaY;
        newX = this.resizeStartLeft + deltaX;
        newY = this.resizeStartTop + deltaY;
        break;

      case 'n': // North (top)
        newHeight = this.resizeStartHeight - deltaY;
        newY = this.resizeStartTop + deltaY;
        break;

      case 's': // South (bottom)
        newHeight = this.resizeStartHeight + deltaY;
        break;

      case 'w': // West (left)
        newWidth = this.resizeStartWidth - deltaX;
        newX = this.resizeStartLeft + deltaX;
        break;

      case 'e': // East (right)
        newWidth = this.resizeStartWidth + deltaX;
        break;
    }

    // Apply constraints
    newWidth = Math.max(minWidth, Math.min(newWidth, maxWidth));
    newHeight = Math.max(minHeight, Math.min(newHeight, maxHeight));

    // Adjust position if width/height hit minimum
    if (newWidth === minWidth && (this.resizeDirection.includes('w'))) {
      newX = this.resizeStartLeft + (this.resizeStartWidth - minWidth);
    }
    if (newHeight === minHeight && (this.resizeDirection.includes('n'))) {
      newY = this.resizeStartTop + (this.resizeStartHeight - minHeight);
    }

    // Prevent negative positions
    newX = Math.max(0, newX);
    newY = Math.max(0, newY);

    // Update chart dimensions
    this.resizingChart.width = newWidth;
    this.resizingChart.height = newHeight;
    this.resizingChart.x = newX;
    this.resizingChart.y = newY;

    // Auto-expand canvas if chart is near or beyond current canvas size
    const chartRight = newX + newWidth;
    const chartBottom = newY + newHeight;
    const edgeThreshold = 50;

    if (chartRight + edgeThreshold > this.canvasWidth ||
        chartBottom + edgeThreshold > this.canvasHeight) {
      this.updateCanvasSize();
    }

    // Regenerate chart to update canvas size
    if (this.resizingChart.chartConfig) {
      const oldConfig = this.resizingChart.chartConfig;
      this.resizingChart.chartConfig = { ...oldConfig };
      this.cdRef.detectChanges();
    }
  }

  stopResize(): void {
    this.isResizing = false;
    this.resizingChart = null;
    this.resizeDirection = '';
    this.updateCanvasSize();
  }

  /* ================= EXPAND CANVAS DURING RESIZE ================= */
  expandCanvasDuringResize(): void {
    if (!this.resizingChart) return;

    const chart = this.resizingChart;
    const chartRight = (chart.x || 0) + (chart.width || 180);
    const chartBottom = (chart.y || 0) + (chart.height || 140);

    const expansionThreshold = 50;
    const needsExpansion = 
      chartRight + expansionThreshold > this.canvasWidth ||
      chartBottom + expansionThreshold > this.canvasHeight;

    if (needsExpansion) {
      this.updateCanvasSize();
    }
  }

  /* ================= DESELECT CHART ON CANVAS CLICK ================= */
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    const target = event.target as HTMLElement;
    // Deselect if clicking outside canvas items
    if (!target.closest('.canvas-item') && !target.closest('.property-panel')) {
      this.selectedChartId = null;
    }
  }

  openPropertyPanel(chart: ChartItem): void {
    this.selectedItem = chart;
    this.tempItem     = { ...chart };
    
    this.originalItemValues = {
      x:        chart.x,
      y:        chart.y,
      width:    chart.width,
      height:   chart.height,
      pageId:   chart.pageId,
      fieldXId: chart.fieldXId,
      fieldYId: chart.fieldYId,
      fieldY2Id: chart.fieldY2Id,
      fieldY3Id: chart.fieldY3Id
    };

    this.propertyPanelOpen = true;
    this.hasChanges        = false;
    this.isOverlapping     = false;

    if (chart.pageId) {
      this.updateAvailableFieldKeys(chart.pageId);
    }
  }

  closePropertyPanel(): void {
    this.propertyPanelOpen      = false;
    this.selectedItem           = null;
    this.tempItem               = null;
    this.originalItemValues     = null;
    this.hasChanges             = false;
    this.showConfirmationDialog = false;
    this.isOverlapping          = false;
    this.availableFieldNames    = [];
    this.hasFieldsForSelectedPage = false;
  }

  closePropertyPanelWithConfirmation(): void {
    if (this.hasChanges) {
      this.showConfirmationDialog = true;
    } else {
      this.closePropertyPanel();
    }
  }

  continueEditing(): void {
    this.showConfirmationDialog = false;
  }

  discardChanges(): void {
    this.cancelChanges();
    this.showConfirmationDialog = false;
    this.closePropertyPanel();
  }

  saveAndClose(): void {
    this.saveChanges();
    this.showConfirmationDialog = false;
    this.closePropertyPanel();
  }

  saveChanges(): void {
    if (!this.selectedItem || !this.tempItem || this.isOverlapping || this.isLoadingData) {
      return;
    }

    this.selectedItem.x        = this.tempItem.x;
    this.selectedItem.y        = this.tempItem.y;
    this.selectedItem.width    = this.tempItem.width;
    this.selectedItem.height   = this.tempItem.height;
    this.selectedItem.pageId   = this.tempItem.pageId;
    this.selectedItem.fieldXId = this.tempItem.fieldXId;
    this.selectedItem.fieldYId = this.tempItem.fieldYId;
    this.selectedItem.fieldY2Id = this.tempItem.fieldY2Id;
    this.selectedItem.fieldY3Id = this.tempItem.fieldY3Id;

    this.generateChartConfig(this.selectedItem);
    this.adjustNearbyChartsAfterSave();

    this.originalItemValues = {
      x:        this.selectedItem.x,
      y:        this.selectedItem.y,
      width:    this.selectedItem.width,
      height:   this.selectedItem.height,
      pageId:   this.selectedItem.pageId,
      fieldXId: this.selectedItem.fieldXId,
      fieldYId: this.selectedItem.fieldYId,
      fieldY2Id: this.selectedItem.fieldY2Id,
      fieldY3Id: this.selectedItem.fieldY3Id
    };

    this.hasChanges    = false;
    this.isOverlapping = false;

    this.cdRef.detectChanges();
    this.updateCanvasSize();
  }

  cancelChanges(): void {
    if (!this.selectedItem || !this.originalItemValues) return;

    this.selectedItem.x        = this.originalItemValues.x;
    this.selectedItem.y        = this.originalItemValues.y;
    this.selectedItem.width    = this.originalItemValues.width;
    this.selectedItem.height   = this.originalItemValues.height;
    this.selectedItem.pageId   = this.originalItemValues.pageId;
    this.selectedItem.fieldXId = this.originalItemValues.fieldXId;
    this.selectedItem.fieldYId = this.originalItemValues.fieldYId;
    this.selectedItem.fieldY2Id = this.originalItemValues.fieldY2Id;
    this.selectedItem.fieldY3Id = this.originalItemValues.fieldY3Id;

    this.generateChartConfig(this.selectedItem);

    if (this.tempItem) {
      this.tempItem.x        = this.originalItemValues.x;
      this.tempItem.y        = this.originalItemValues.y;
      this.tempItem.width    = this.originalItemValues.width;
      this.tempItem.height   = this.originalItemValues.height;
      this.tempItem.pageId   = this.originalItemValues.pageId;
      this.tempItem.fieldXId = this.originalItemValues.fieldXId;
      this.tempItem.fieldYId = this.originalItemValues.fieldYId;
      this.tempItem.fieldY2Id = this.originalItemValues.fieldY2Id;
      this.tempItem.fieldY3Id = this.originalItemValues.fieldY3Id;
    }

    this.hasChanges    = false;
    this.isOverlapping = false;
    this.cdRef.detectChanges();
    this.updateCanvasSize();
  }

  updateChartInRealTime(): void {
    if (!this.selectedItem || !this.tempItem) return;

    // Clamp values
    this.tempItem.x      = Math.max(0, this.tempItem.x || 0);
    this.tempItem.y      = Math.max(0, this.tempItem.y || 0);
    this.tempItem.width  = Math.max(120, Math.min(this.tempItem.width  || 180, 800));
    this.tempItem.height = Math.max(100, Math.min(this.tempItem.height || 140, 600));

    // Apply to selected item immediately
    this.selectedItem.x        = this.tempItem.x;
    this.selectedItem.y        = this.tempItem.y;
    this.selectedItem.width    = this.tempItem.width;
    this.selectedItem.height   = this.tempItem.height;
    this.selectedItem.pageId   = this.tempItem.pageId;
    this.selectedItem.fieldXId = this.tempItem.fieldXId;
    this.selectedItem.fieldYId = this.tempItem.fieldYId;
    this.selectedItem.fieldY2Id = this.tempItem.fieldY2Id;
    this.selectedItem.fieldY3Id = this.tempItem.fieldY3Id;

    // If chart exists, regenerate to trigger resize
    if (this.selectedItem.chartConfig) {
      // Create a new reference to force change detection
      const oldConfig = this.selectedItem.chartConfig;
      this.selectedItem.chartConfig = { ...oldConfig };
      
      // Force Angular to detect the change
      this.cdRef.detectChanges();
    }

    this.checkForChanges();
    this.checkForOverlap();
    this.updateCanvasSize();
  }

  private checkForChanges(): void {
    if (!this.selectedItem || !this.tempItem || !this.originalItemValues) return;

    this.hasChanges =
      this.tempItem.x        !== this.originalItemValues.x        ||
      this.tempItem.y        !== this.originalItemValues.y        ||
      this.tempItem.width    !== this.originalItemValues.width    ||
      this.tempItem.height   !== this.originalItemValues.height   ||
      this.tempItem.pageId   !== this.originalItemValues.pageId   ||
      this.tempItem.fieldXId !== this.originalItemValues.fieldXId ||
      this.tempItem.fieldYId !== this.originalItemValues.fieldYId ||
      this.tempItem.fieldY2Id !== this.originalItemValues.fieldY2Id ||
      this.tempItem.fieldY3Id !== this.originalItemValues.fieldY3Id;
  }

  private checkForOverlap(): void {
    if (!this.selectedItem) return;

    const itemIndex = this.service.canvasCharts.findIndex(
      item => item.id === this.selectedItem!.id
    );
    if (itemIndex === -1) return;

    this.isOverlapping = this.service.wouldCauseCollision(
      this.selectedItem, itemIndex
    );
  }

  private adjustNearbyChartsAfterSave(): void {
    if (!this.selectedItem) return;

    const itemIndex = this.service.canvasCharts.findIndex(
      item => item.id === this.selectedItem!.id
    );
    if (itemIndex === -1) return;

    if (!this.service.wouldCauseCollision(this.selectedItem, itemIndex)) return;

    const affectedCharts = this.service.findChartsAffectedByMovement(
      this.selectedItem, itemIndex
    );

    affectedCharts.forEach(({ chart, index, direction }) => {
      if (direction) {
        const [newX, newY] = this.service.adjustChartForResize(
          chart, index, this.selectedItem!, direction
        );
        chart.x = newX;
        chart.y = newY;
      }
    });

    if (this.service.wouldCauseCollision(this.selectedItem, itemIndex)) {
      const [newX, newY] = this.service.findFreePositionForPropertyPanel(
        this.selectedItem.x      || 0,
        this.selectedItem.y      || 0,
        this.selectedItem.width  || 180,
        this.selectedItem.height || 140,
        itemIndex
      );
      this.selectedItem.x = newX;
      this.selectedItem.y = newY;
      if (this.tempItem) {
        this.tempItem.x = newX;
        this.tempItem.y = newY;
      }
    }
  }

  updateCanvasSize(): void {
    const minWidth  = 1200;
    const minHeight = 800;
    const padding   = 100;
    let maxX = minWidth;
    let maxY = minHeight;

    this.service.canvasCharts.forEach(chart => {
      maxX = Math.max(maxX, (chart.x || 0) + (chart.width  || 180) + padding);
      maxY = Math.max(maxY, (chart.y || 0) + (chart.height || 140) + padding);
    });

    this.canvasWidth  = maxX;
    this.canvasHeight = maxY;
    this.cdRef.detectChanges();
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    this.updateCanvasSize();
    if (this.selectedItem?.id === id) {
      this.closePropertyPanel();
    }
  }

  getIconName(type: string): string {
    return this.service.getIconName(type);
  }

  toggleSidebar(): void {
    this.isSidebarCollapsed = !this.isSidebarCollapsed;
  }

  addTestLineChart(): void {
    const testChart: ChartItem = {
      id:       this.service.nextId++,
      name:     'Line Chart',
      type:     'line',
      icon:     'show_chart',
      x:        50,
      y:        50,
      width:    300,
      height:   200,
      zIndex:   ++this.service.zIndexCounter,
      pageId:   '',
      fieldXId: '',
      fieldYId: ''
    };
    this.service.canvasCharts.push(testChart);
    this.cdRef.detectChanges();
  }
}