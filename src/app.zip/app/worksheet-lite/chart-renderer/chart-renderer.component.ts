import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  ViewChild,
  ElementRef,
  AfterViewInit,
  OnDestroy,
  ChangeDetectorRef
} from '@angular/core';
import { Chart, registerables } from 'chart.js';

interface ChartConfig {
  type: string;
  data: any;
  options: any;
}

const HEADER_HEIGHT = 33;

@Component({
  selector: 'app-chart-renderer',
  templateUrl: './chart-renderer.component.html',
  styleUrls: ['./chart-renderer.component.css']
})
export class ChartRendererComponent implements AfterViewInit, OnChanges, OnDestroy {

  @Input() chartConfig!: ChartConfig;
  @Input() width: number  = 180;
  @Input() height: number = 140;
  @Input() chartId: string = '';

  @ViewChild('chartCanvas', { static: false })
  chartCanvas!: ElementRef<HTMLCanvasElement>;

  private chartInstance: any = null;
  private isInitialized = false;

  constructor(private cdRef: ChangeDetectorRef) {
    Chart.register(...registerables);
  }

  ngAfterViewInit(): void {
    this.isInitialized = true;
    if (this.chartConfig) {
      setTimeout(() => this.createChart(), 0);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.isInitialized) return;

    const configChanged = changes['chartConfig'];
    const widthChanged  = changes['width'];
    const heightChanged = changes['height'];

    if (configChanged) {
      if (this.chartConfig) {
        setTimeout(() => this.createChart(), 0);
      } else {
        this.destroyChart();
      }
      return;
    }

    if ((widthChanged || heightChanged) && this.chartInstance) {
      setTimeout(() => this.resizeChart(), 0);
    }
  }

  ngOnDestroy(): void {
    this.destroyChart();
  }

  private createChart(): void {
    if (!this.chartCanvas?.nativeElement || !this.chartConfig) {
      return;
    }

    const canvas = this.chartCanvas.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    try {
      this.destroyChart();

      const validWidth  = Math.max(50, this.width || 180);
      const validHeight = Math.max(50, this.height || 140);
      
      canvas.width  = validWidth;
      canvas.height = validHeight;
      canvas.style.width  = `${validWidth}px`;
      canvas.style.height = `${validHeight}px`;

      console.log(`📊 Creating chart: ${validWidth}x${validHeight} [${this.chartId}]`);

      const config: any = {
        type: this.chartConfig.type,
        data: this.chartConfig.data,
        options: {
          ...this.chartConfig.options,
          responsive: false,
          maintainAspectRatio: false,
          layout: {
            padding: 0
          }
        }
      };

      this.chartInstance = new Chart(ctx, config);
      console.log(`✅ Chart created [${this.chartId}]`);

    } catch (error) {
      console.error('Chart creation error:', error);
      this.chartInstance = null;
    }
  }

  private resizeChart(): void {
    if (!this.chartCanvas?.nativeElement || !this.chartInstance) {
      return;
    }

    const canvas = this.chartCanvas.nativeElement;
    const validWidth  = Math.max(50, this.width || 180);
    const validHeight = Math.max(50, this.height || 140);

    console.log(`📐 Resizing chart: ${validWidth}x${validHeight} [${this.chartId}]`);

    try {
      canvas.width  = validWidth;
      canvas.height = validHeight;
      canvas.style.width  = `${validWidth}px`;
      canvas.style.height = `${validHeight}px`;

      this.chartInstance.resize(validWidth, validHeight);
      this.chartInstance.update('none');
      
      console.log(`✅ Chart resized [${this.chartId}]`);

    } catch (error) {
      console.error('Resize error:', error);
      this.createChart();
    }
  }

  private destroyChart(): void {
    if (this.chartInstance) {
      try {
        this.chartInstance.destroy();
      } catch (error) {
        console.error('Destroy error:', error);
      } finally {
        this.chartInstance = null;
      }
    }
  }
}