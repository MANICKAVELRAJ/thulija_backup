import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { Observable, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';

import { ChartConfig } from './chart-data.service';

/* ================= PAGE DATA INTERFACE ================= */
export interface PageData {
  id: string;
  project_id: string;
  logical_module_id: string;
  package_name: string;
  table_name: string;
  class_name: string;
  class_name_plural: string;
  [key: string]: any;
}

/* ================= FIELD DATA INTERFACE ================= */
export interface FieldData {
  id: string;
  project_id: string;
  logical_module_id: string;
  page_id: string;
  column_name: string;
  property_name: string;
  data_type_id: string | null;
  [key: string]: any;
}

/* ================= KEY NAME INTERFACE ================= */
export interface KeyName {
  key: string;
  displayName: string;
}

/* ================= CHART ITEM INTERFACE ================= */
export interface ChartItem {
  id: number;
  name: string;
  type: string;
  icon?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  pageId?: string;
  fieldXId?: string;
  fieldYId?: string;
  // NEW: Additional Y fields for stacked area chart
  fieldY2Id?: string;
  fieldY3Id?: string;
  chartConfig?: ChartConfig;
}

interface AffectedChart {
  chart: ChartItem;
  index: number;
  direction: 'right' | 'left' | 'up' | 'down';
}

interface JsonDataResponse {
  pages: PageData[];
  fields: FieldData[];
}

@Injectable({
  providedIn: 'root'
})
export class WorksheetLiteService {
  
  /* ================= DATA - ONLY 3 CHART TYPES ================= */
  chartTypes: ChartItem[] = [
    {
      id: 1,
      name: 'Line Chart',
      type: 'line',
      icon: 'show_chart'
    },
    {
      id: 2,
      name: 'Area Chart',
      type: 'area',
      icon: 'area_chart'
    },
    {
      id: 3,
      name: 'Stacked Area Chart',
      type: 'stacked-area',
      icon: 'stacked_line_chart'
    }
  ];
  
  canvasCharts: ChartItem[] = [];

  /* ================= CANVAS ================= */
  nextId = 1000;
  zIndexCounter = 10;

  canvasEl!: HTMLElement;
  componentRef: any = null;
  movingIndex: number | null = null;
  offsetX = 0;
  offsetY = 0;

  /* ================= COLLISION DETECTION ================= */
  private readonly MIN_DISTANCE = 16;
  private readonly MIN_WIDTH = 120;
  private readonly MIN_HEIGHT = 100;
  private readonly MAX_WIDTH = 800;
  private readonly MAX_HEIGHT = 600;

  constructor(private http: HttpClient) {}

  /* ================= LOAD PAGES AND FIELDS FROM JSON ================= */
  loadPagesAndFields(): Observable<JsonDataResponse> {
    return forkJoin({
      pages: this.loadPages(),
      fields: this.loadFields()
    }).pipe(
      map(({ pages, fields }) => {
        console.log('Pages loaded from JSON:', pages.length);
        console.log('Fields loaded from JSON:', fields.length);
        
        return {
          pages,
          fields
        };
      })
    );
  }

  /* ================= LOAD PAGES FROM JSON ================= */
  private loadPages(): Observable<PageData[]> {
    return this.http.get<PageData[]>('assets/pages.json').pipe(
      map(pages => {
        return pages;
      })
    );
  }

  /* ================= LOAD FIELDS FROM JSON ================= */
  private loadFields(): Observable<FieldData[]> {
    return this.http.get<FieldData[]>('assets/fields.json').pipe(
      map(fields => {
        return fields;
      })
    );
  }

  /* ================= INIT ================= */
  initCanvas(el: HTMLElement, componentRef: any): void {
    this.canvasEl = el;
    this.componentRef = componentRef;
  }

  /* ================= LOAD CHARTS ================= */
  loadCharts(): ChartItem[] {
    return this.chartTypes;
  }

  /* ================= DROP ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    if (event.previousContainer.id !== 'chartList') return;

    const draggedChart = event.item.data as ChartItem;
    const rect = this.canvasEl.getBoundingClientRect();
    const mouse = event.event as MouseEvent;

    const width = 180;
    const height = 140;

    let x = mouse.clientX - rect.left - width / 2;
    let y = mouse.clientY - rect.top - height / 2;

    [x, y] = this.findFreePosition(x, y, width, height);

    const newChart: ChartItem = {
      id: this.nextId++,
      name: draggedChart.name,
      type: draggedChart.type,
      icon: draggedChart.icon,
      x,
      y,
      width,
      height,
      zIndex: ++this.zIndexCounter,
      pageId: '',
      fieldXId: '',
      fieldYId: '',
      fieldY2Id: '',
      fieldY3Id: ''
    };

    this.canvasCharts.push(newChart);
    
    event.previousContainer.data = [...this.chartTypes];
    event.container.data = [...this.canvasCharts];

    if (this.componentRef) {
      setTimeout(() => {
        this.componentRef.updateCanvasSize();
      }, 10);
    }
  }

  /* ================= OVERLAP DETECTION ================= */
  checkCollision(
    x1: number, y1: number, w1: number, h1: number,
    x2: number, y2: number, w2: number, h2: number
  ): boolean {
    return !(
      x1 + w1 < x2 ||
      x1 > x2 + w2 ||
      y1 + h1 < y2 ||
      y1 > y2 + h2
    );
  }

  checkCollisionWithMargin(
    x1: number, y1: number, w1: number, h1: number,
    x2: number, y2: number, w2: number, h2: number
  ): boolean {
    return !(
      x1 + w1 + this.MIN_DISTANCE < x2 ||
      x1 > x2 + w2 + this.MIN_DISTANCE ||
      y1 + h1 + this.MIN_DISTANCE < y2 ||
      y1 > y2 + h2 + this.MIN_DISTANCE
    );
  }

  /* ================= FIND FREE POSITION ================= */
  findFreePosition(
    x: number,
    y: number,
    width: number,
    height: number,
    ignoreIndex: number = -1
  ): [number, number] {
    const maxAttempts = 100;
    
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      let hasCollision = false;
      
      for (let i = 0; i < this.canvasCharts.length; i++) {
        if (i === ignoreIndex) continue;
        
        const c = this.canvasCharts[i];
        if (this.checkCollisionWithMargin(
          x, y, width, height,
          c.x!, c.y!, c.width!, c.height!
        )) {
          hasCollision = true;
          break;
        }
      }
      
      if (!hasCollision) {
        return [x, y];
      }
      
      x += this.MIN_DISTANCE + 10;
      
      const maxWidth = this.componentRef ? this.componentRef.canvasWidth : this.canvasEl.clientWidth;
      if (x + width > maxWidth) {
        x = this.MIN_DISTANCE;
        y += height + this.MIN_DISTANCE;
      }
    }
    
    return [x, y];
  }

  findFreePositionForPropertyPanel(
    x: number,
    y: number,
    width: number,
    height: number,
    ignoreIndex: number
  ): [number, number] {
    const directions = [
      { dx: this.MIN_DISTANCE + 10, dy: 0 },
      { dx: 0, dy: this.MIN_DISTANCE + 10 },
      { dx: -(this.MIN_DISTANCE + 10), dy: 0 },
      { dx: 0, dy: -(this.MIN_DISTANCE + 10) }
    ];
    
    for (const dir of directions) {
      const newX = x + dir.dx;
      const newY = y + dir.dy;
      
      if (newX < 0 || newY < 0) continue;
      
      let hasCollision = false;
      
      for (let i = 0; i < this.canvasCharts.length; i++) {
        if (i === ignoreIndex) continue;
        
        const c = this.canvasCharts[i];
        if (this.checkCollisionWithMargin(
          newX, newY, width, height,
          c.x!, c.y!, c.width!, c.height!
        )) {
          hasCollision = true;
          break;
        }
      }
      
      if (!hasCollision) {
        return [newX, newY];
      }
    }
    
    return this.findFreePosition(x, y, width, height, ignoreIndex);
  }

  /* ================= SIZE ADJUSTMENT ================= */
  adjustSizeToAvoidCollisions(
    item: ChartItem,
    itemIndex: number
  ): [number, number] {
    let width = Math.max(this.MIN_WIDTH, Math.min(item.width || 180, this.MAX_WIDTH));
    let height = Math.max(this.MIN_HEIGHT, Math.min(item.height || 140, this.MAX_HEIGHT));
    
    const originalWidth = width;
    const originalHeight = height;
    
    for (let attempt = 0; attempt < 50; attempt++) {
      let hasCollision = false;
      
      for (let i = 0; i < this.canvasCharts.length; i++) {
        if (i === itemIndex) continue;
        
        const c = this.canvasCharts[i];
        if (this.checkCollisionWithMargin(
          item.x!, item.y!, width, height,
          c.x!, c.y!, c.width!, c.height!
        )) {
          hasCollision = true;
          width = Math.max(this.MIN_WIDTH, width - 10);
          height = Math.max(this.MIN_HEIGHT, height - 8);
          break;
        }
      }
      
      if (!hasCollision) {
        return [width, height];
      }
    }
    
    return [originalWidth, originalHeight];
  }

  /* ================= COLLISION PREDICTION ================= */
  wouldCauseCollision(item: ChartItem, itemIndex: number): boolean {
    for (let i = 0; i < this.canvasCharts.length; i++) {
      if (i === itemIndex) continue;
      
      const c = this.canvasCharts[i];
      if (this.checkCollision(
        item.x || 0, item.y || 0, item.width || 180, item.height || 140,
        c.x!, c.y!, c.width!, c.height!
      )) {
        return true;
      }
    }
    return false;
  }

  /* ================= FIND CHARTS AFFECTED BY MOVEMENT ================= */
  findChartsAffectedByMovement(
    movingChart: ChartItem,
    movingIndex: number
  ): AffectedChart[] {
    const affectedCharts: AffectedChart[] = [];
    
    for (let i = 0; i < this.canvasCharts.length; i++) {
      if (i === movingIndex) continue;
      
      const chart = this.canvasCharts[i];
      
      if (this.checkCollision(
        movingChart.x || 0, movingChart.y || 0, movingChart.width || 180, movingChart.height || 140,
        chart.x!, chart.y!, chart.width!, chart.height!
      )) {
        const direction = this.getAdjustmentDirection(movingChart, chart);
        affectedCharts.push({ chart, index: i, direction });
      }
    }
    
    return affectedCharts;
  }

  /* ================= FIND CHARTS AFFECTED BY RESIZE ================= */
  findChartsAffectedByResize(
    resizingChart: ChartItem,
    resizingIndex: number
  ): AffectedChart[] {
    const affectedCharts: AffectedChart[] = [];
    
    for (let i = 0; i < this.canvasCharts.length; i++) {
      if (i === resizingIndex) continue;
      
      const chart = this.canvasCharts[i];
      
      if (this.checkCollision(
        resizingChart.x || 0, resizingChart.y || 0, resizingChart.width || 180, resizingChart.height || 140,
        chart.x!, chart.y!, chart.width!, chart.height!
      )) {
        const direction = this.getAdjustmentDirection(resizingChart, chart);
        affectedCharts.push({ chart, index: i, direction });
      }
    }
    
    return affectedCharts;
  }

  /* ================= GET ADJUSTMENT DIRECTION ================= */
  private getAdjustmentDirection(chart1: ChartItem, chart2: ChartItem): 'right' | 'left' | 'up' | 'down' {
    const chart1Right = (chart1.x || 0) + (chart1.width || 180);
    const chart1Bottom = (chart1.y || 0) + (chart1.height || 140);
    const chart2Right = (chart2.x || 0) + (chart2.width || 180);
    const chart2Bottom = (chart2.y || 0) + (chart2.height || 140);
    
    const distanceRight = Math.abs(chart2Right - (chart1.x || 0));
    const distanceLeft = Math.abs(chart1Right - (chart2.x || 0));
    const distanceDown = Math.abs(chart2Bottom - (chart1.y || 0));
    const distanceUp = Math.abs(chart1Bottom - (chart2.y || 0));
    
    const minDistance = Math.min(distanceRight, distanceLeft, distanceDown, distanceUp);
    
    if (minDistance === distanceRight) {
      return 'right';
    } else if (minDistance === distanceLeft) {
      return 'left';
    } else if (minDistance === distanceDown) {
      return 'down';
    } else {
      return 'up';
    }
  }

  /* ================= ADJUST CHART FOR RESIZE ================= */
  adjustChartForResize(
    chartToAdjust: ChartItem,
    chartIndex: number,
    resizingChart: ChartItem,
    direction: 'right' | 'left' | 'up' | 'down'
  ): [number, number] {
    let newX = chartToAdjust.x || 0;
    let newY = chartToAdjust.y || 0;
    
    switch (direction) {
      case 'right':
        newX = (resizingChart.x || 0) + (resizingChart.width || 180) + this.MIN_DISTANCE;
        break;
      case 'left':
        newX = (resizingChart.x || 0) - (chartToAdjust.width || 180) - this.MIN_DISTANCE;
        break;
      case 'down':
        newY = (resizingChart.y || 0) + (resizingChart.height || 140) + this.MIN_DISTANCE;
        break;
      case 'up':
        newY = (resizingChart.y || 0) - (chartToAdjust.height || 140) - this.MIN_DISTANCE;
        break;
    }
    
    const maxWidth = this.componentRef ? this.componentRef.canvasWidth : this.canvasEl.clientWidth;
    const maxHeight = this.componentRef ? this.componentRef.canvasHeight : this.canvasEl.clientHeight;
    
    newX = Math.max(0, Math.min(newX, maxWidth - (chartToAdjust.width || 180)));
    newY = Math.max(0, Math.min(newY, maxHeight - (chartToAdjust.height || 140)));
    
    return this.findFreePosition(newX, newY, chartToAdjust.width || 180, chartToAdjust.height || 140, chartIndex);
  }

  /* ================= MOVE ================= */
  startMove(event: MouseEvent, index: number): void {
    this.movingIndex = index;
    const item = this.canvasCharts[index];
    item.zIndex = ++this.zIndexCounter;
    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  moveItem(event: MouseEvent): void {
    if (this.movingIndex === null) return;

    const rect = this.canvasEl.getBoundingClientRect();
    const item = this.canvasCharts[this.movingIndex];

    const maxWidth = this.componentRef ? this.componentRef.canvasWidth : this.canvasEl.clientWidth;
    const maxHeight = this.componentRef ? this.componentRef.canvasHeight : this.canvasEl.clientHeight;

    item.x = Math.max(
      0,
      Math.min(
        event.clientX - rect.left - this.offsetX,
        maxWidth - item.width!
      )
    );

    item.y = Math.max(
      0,
      Math.min(
        event.clientY - rect.top - this.offsetY,
        maxHeight - item.height!
      )
    );

    this.checkCanvasExpansion(item);
  }

  stopMove(): void {
    if (this.movingIndex === null) return;

    const item = this.canvasCharts[this.movingIndex];
    const [x, y] = this.findFreePosition(
      item.x!,
      item.y!,
      item.width!,
      item.height!,
      this.movingIndex
    );

    item.x = x;
    item.y = y;
    this.movingIndex = null;

    if (this.componentRef) {
      setTimeout(() => {
        this.componentRef.updateCanvasSize();
      }, 10);
    }
  }

  /* ================= CANVAS EXPANSION CHECK ================= */
  private checkCanvasExpansion(item: ChartItem): void {
    if (!this.componentRef) return;

    const chartRight = (item.x || 0) + (item.width || 180);
    const chartBottom = (item.y || 0) + (item.height || 140);
    
    const edgeThreshold = 100;
    const currentWidth = this.componentRef.canvasWidth;
    const currentHeight = this.componentRef.canvasHeight;
    
    if (chartRight + edgeThreshold > currentWidth || 
        chartBottom + edgeThreshold > currentHeight) {
      this.componentRef.updateCanvasSize();
    }
  }

  /* ================= HELPERS ================= */
  removeChart(id: number): void {
    this.canvasCharts = this.canvasCharts.filter(c => c.id !== id);
    
    if (this.componentRef) {
      setTimeout(() => {
        this.componentRef.updateCanvasSize();
      }, 10);
    }
  }

  getIconName(type: string): string {
    const chart = this.chartTypes.find(c => c.type === type);
    return chart?.icon || 'insert_chart';
  }
}