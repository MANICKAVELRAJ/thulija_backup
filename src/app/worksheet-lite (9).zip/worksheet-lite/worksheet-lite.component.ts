import {
  Component,
  OnInit,
  AfterViewInit,
  HostListener
} from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { WorksheetLiteService, PageItem } from './worksheet-lite.service';
import { ChartItem } from './chart-gen.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  /* ===================== SIDEBAR ===================== */
  isSidebarCollapsed = false;

  /* ===================== FILE UPLOAD ===================== */
  uploadProgress    = 0;
  isCustomDataUploaded = false;

  /* ===================== PROPERTY PANEL ===================== */
  propertyPanelOpen = false;
  selectedItem:     ChartItem | null = null;
  editableItem:     ChartItem | null = null;
  originalSnapshot: ChartItem | null = null;

  pages: PageItem[] = [];

  /* ===================== AVAILABLE FIELDS ===================== */
  // Populated after table is chosen or file is uploaded
  availableFields: string[] = [];

  chartRequirements: any = null;

  /* ===================== RESIZE STATE ===================== */
  private resizingIndex   = -1;
  private resizeDirection = '';
  private resizeStartX    = 0;
  private resizeStartY    = 0;
  private resizeStartW    = 0;
  private resizeStartH    = 0;
  private resizeStartLeft = 0;
  private resizeStartTop  = 0;

  readonly MIN_W = 180;
  readonly MIN_H = 140;

  constructor(
    public  service:  WorksheetLiteService,
    private snackBar: MatSnackBar
  ) {}

  /* ================================================================
     LIFECYCLE
  ================================================================ */
  ngOnInit(): void {
    this.service.loadCharts();
    this.service.loadWorkflow();

    this.service.fields$.subscribe(fields => {
      if (fields.length > 0) this.updateChartsWithNewData();
    });

    this.service.pages$.subscribe(pages => {
      this.pages = pages || [];
    });
  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    if (canvas) this.service.initCanvas(canvas);
  }

  /* ================================================================
     CANVAS DROP
  ================================================================ */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
    const last = this.service.canvasCharts[this.service.canvasCharts.length - 1];
    if (last) this.openPropertyPanel(last);
  }

  /* ================================================================
     MOVE
  ================================================================ */
  startMove(event: MouseEvent, index: number): void {
    if ((event.target as HTMLElement).classList.contains('resize-handle')) return;
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    if (this.resizingIndex >= 0) this.doResize(event);
    else this.service.moveItem(event);
  }

  @HostListener('document:mouseup')
  onMouseUp(): void {
    if (this.resizingIndex >= 0) this.stopResize();
    else this.service.stopMove();
  }

  /* ================================================================
     RESIZE
  ================================================================ */
  startResize(event: MouseEvent, index: number, direction: string): void {
    event.preventDefault(); event.stopPropagation();
    const c = this.service.canvasCharts[index];
    this.resizingIndex   = index;
    this.resizeDirection = direction;
    this.resizeStartX    = event.clientX;
    this.resizeStartY    = event.clientY;
    this.resizeStartW    = c.width  ?? this.MIN_W;
    this.resizeStartH    = c.height ?? this.MIN_H;
    this.resizeStartLeft = c.x      ?? 0;
    this.resizeStartTop  = c.y      ?? 0;
  }

  private doResize(event: MouseEvent): void {
    if (this.resizingIndex < 0) return;
    const c   = this.service.canvasCharts[this.resizingIndex];
    const dx  = event.clientX - this.resizeStartX;
    const dy  = event.clientY - this.resizeStartY;
    const dir = this.resizeDirection;
    const maxW = this.service.canvasEl?.clientWidth  ?? 9999;
    const maxH = this.service.canvasEl?.clientHeight ?? 9999;

    let newW = this.resizeStartW, newH = this.resizeStartH;
    let newX = this.resizeStartLeft, newY = this.resizeStartTop;

    if (dir.includes('e')) newW = Math.min(maxW-newX, Math.max(this.MIN_W, this.resizeStartW+dx));
    if (dir.includes('w')) { newX = Math.max(0, this.resizeStartLeft+dx); newW = Math.max(this.MIN_W, this.resizeStartLeft+this.resizeStartW-newX); }
    if (dir.includes('s')) newH = Math.min(maxH-newY, Math.max(this.MIN_H, this.resizeStartH+dy));
    if (dir.includes('n')) { newY = Math.max(0, this.resizeStartTop+dy);  newH = Math.max(this.MIN_H, this.resizeStartTop+this.resizeStartH-newY); }

    c.width=Math.round(newW); c.height=Math.round(newH);
    c.x=Math.round(newX);    c.y=Math.round(newY);
  }

  private stopResize(): void { this.resizingIndex=-1; this.resizeDirection=''; }

  /* ================================================================
     PROPERTY PANEL OPEN
  ================================================================ */
  openPropertyPanel(chart: ChartItem): void {
    this.isCustomDataUploaded = false;
    this.selectedItem         = chart;
    this.originalSnapshot     = JSON.parse(JSON.stringify(chart));

    this.editableItem = {
      ...chart,
      x:      Math.round(chart.x      ?? 0),
      y:      Math.round(chart.y      ?? 0),
      width:  Math.round(chart.width  ?? this.MIN_W),
      height: Math.round(chart.height ?? this.MIN_H)
    };

    // If chart already has data (previously configured), populate fields
    if (this.editableItem.data?.length) {
      if (this.editableItem.data.length > 0) {
        this.availableFields = Object.keys(this.editableItem.data[0]);
      }
    } else if (this.editableItem.tableId) {
      // Re-fetch data from stored tableId
      const page = this.pages.find(p => p.id === this.editableItem!.tableId);
      if (page) {
        const rows = this.service.allFields.filter(f => f.page_id == page.id);
        this.editableItem.data = rows;
        if (rows.length > 0) {
            this.availableFields = Object.keys(rows[0]);
        }
      }
    } else {
      this.availableFields = [];
    }

    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
    this.propertyPanelOpen = true;
  }

  /* ================================================================
     TABLE SELECT — Fetch rows & populate fields
  ================================================================ */
  onTableSelect(tableValue: string): void {
    const tableId = +tableValue;
    if (!this.editableItem || !tableId) return;

    const page = this.pages.find(p => p.id == tableId);
    if (!page) return;

    // Fetch rows for this page
    const rows = this.service.allFields.filter(f => f.page_id == page.id);

    // Extract fields
    let fields: string[] = [];
    if (rows.length > 0) {
        fields = Object.keys(rows[0]);
    }
    this.availableFields = fields;

    // NEW object reference -> ChartRendererComponent ngOnChanges fires immediately
    this.editableItem = {
      ...this.editableItem,
      tableId:   +page.id,
      tableName: page.table_name,
      data:      rows,
      fields:    fields,    // available fields in dropdown
      isXYEnabled: true,
      xField:    this.editableItem.xField || (fields.length > 0 ? fields[0] : ''),
      yField:    this.editableItem.yField || ''
    };

    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);

    this.snackBar.open(
      `Loaded ${rows.length} rows, ${fields.length} fields`,
      'OK', { duration: 3000, horizontalPosition: 'right' }
    );
  }

  /* ================================================================
     CHART TYPE CHANGE
  ================================================================ */
  onChartTypeChange(newType: string): void {
    if (!this.editableItem) return;
    this.chartRequirements = this.service.getChartRequirements(newType);
    this.editableItem = { ...this.editableItem, type: newType };
  }

  /* ================================================================
     FIELD CHANGE — new reference triggers live preview
  ================================================================ */
  onXFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem = { ...this.editableItem, xField: fieldName };
    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
  }

  onYFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem = { ...this.editableItem, yField: fieldName };
  }

  /* ================================================================
     SAVE — replaces array slot with new object -> ngOnChanges fires
  ================================================================ */
  saveChanges(): void {
    if (!this.selectedItem || !this.editableItem) return;
    const idx = this.service.canvasCharts.findIndex(c => c.id === this.selectedItem!.id);
    if (idx !== -1) {
      this.service.canvasCharts[idx] = { ...this.editableItem };
    }
    this.cleanupPropertyPanel();
  }

  /* ================================================================
     CANCEL — restore snapshot with new reference
  ================================================================ */
  cancelChanges(): void {
    if (this.selectedItem && this.originalSnapshot) {
      const idx = this.service.canvasCharts.findIndex(c => c.id === this.selectedItem!.id);
      if (idx !== -1) {
        this.service.canvasCharts[idx] = { ...this.originalSnapshot };
      }
    }
    this.cleanupPropertyPanel();
  }

  cleanupPropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem      = null;
    this.editableItem      = null;
    this.originalSnapshot  = null;
    this.uploadProgress    = 0;
    this.availableFields   = [];
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) this.cleanupPropertyPanel();
  }

  /* ================================================================
     SIZE CHANGE
  ================================================================ */
  onSizeChange(): void {
    if (!this.editableItem) return;
    if ((this.editableItem.width  ?? 0) < this.MIN_W) this.editableItem.width  = this.MIN_W;
    if ((this.editableItem.height ?? 0) < this.MIN_H) this.editableItem.height = this.MIN_H;
    const el = this.service.canvasEl;
    if (el) {
      const mw = el.clientWidth  - (this.editableItem.x ?? 0);
      const mh = el.clientHeight - (this.editableItem.y ?? 0);
      if ((this.editableItem.width  ?? 0) > mw) this.editableItem.width  = mw;
      if ((this.editableItem.height ?? 0) > mh) this.editableItem.height = mh;
    }
  }

  checkOverlapLive(item: ChartItem): void {
    if (!item) return;
    const idx = this.service.canvasCharts.findIndex(c => c.id === item.id);
    if (idx === -1) return;
    const [nx, ny] = this.service.findFreePosition(
      item.x??0, item.y??0, item.width??0, item.height??0, idx
    );
    item.x = nx; item.y = ny;
  }

  /* ================================================================
     FILE UPLOAD
  ================================================================ */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;
    const file = input.files[0];
    this.uploadProgress = 0;

    this.service.uploadFile(file, p => { this.uploadProgress = p; }).then(data => {
      this.isCustomDataUploaded = true;
      if (this.editableItem) {
        let fields: string[] = [];
        if (data.length > 0) {
            fields = Object.keys(data[0]);
        }
        this.availableFields = fields;
        
        this.editableItem = {
          ...this.editableItem,
          data:  data,
          fields: fields,
          isXYEnabled: true,
          xField: this.editableItem.xField || (fields.length > 0 ? fields[0] : ''),
          yField: this.editableItem.yField || ''
        };
        this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
      }
      this.uploadProgress = 100;
      setTimeout(() => { this.uploadProgress = 0; }, 2000);
    });
  }

  /* ================================================================
     SIDEBAR
  ================================================================ */
  toggleSidebar(): void { this.isSidebarCollapsed = !this.isSidebarCollapsed; }

  /* ================================================================
     REAL-TIME DATA SYNC
  ================================================================ */
  updateChartsWithNewData(): void {
    this.service.canvasCharts.forEach(chart => {
      if (!chart.tableId) return;
      const nd = this.service.getFieldsByPageId(String(chart.tableId));
      if (nd?.length) chart.data = nd;
    });
  }

}
