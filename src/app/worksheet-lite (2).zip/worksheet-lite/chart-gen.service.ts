import { Injectable } from '@angular/core';
import { Chart, registerables, ChartConfiguration, ChartType } from 'chart.js/auto';

Chart.register(...registerables);

export interface ChartItem {
    id: number;
    name: string;
    type: string;
    image?: string;
    x?: number;
    y?: number;
    zIndex?: number;
    width?: number;
    height?: number;
    isXYEnabled?: boolean;
    tableId?: number;
    tableName?: string;
    fields?: string[];
    data?: any[];
    valueField?: string
    xField?: string;
    yField?: string;
    xFieldId?: number;
    yFieldId?: number;
    xFieldValue?: string;
    yFieldValue?: string;
    // realGraphSvg?: SafeHtml; // Removed
}

@Injectable({
    providedIn: 'root'
})
export class ChartGenService {

    private palette = [
        '#1a73e8', '#34a853', '#fbbc05', '#ea4335', '#46bdc6', '#ff6d01',
        '#673ab7', '#9c27b0', '#0097a7', '#795548', '#607d8b'
    ];

    constructor() { }

    renderChart(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
        const ctx = canvas.getContext('2d');
        if (!ctx) return null;

        let config: ChartConfiguration;

        switch (item.type) {
            case 'bar':
                config = this.getBarConfig(item);
                break;
            case 'column':
                config = this.getColumnConfig(item);
                break;
            case 'line':
                config = this.getLineConfig(item);
                break;
            case 'area':
                config = this.getAreaConfig(item);
                break;
            case 'pie':
                config = this.getPieConfig(item);
                break;
            case 'stackedBar':
                config = this.getStackedBarConfig(item);
                break;
            case 'stackedColumn':
                config = this.getStackedColumnConfig(item);
                break;
            case 'stackedArea':
                config = this.getStackedAreaConfig(item);
                break;
            default:
                return null;
        }

        return new Chart(ctx, config);
    }

    private getBarConfig(item: ChartItem): ChartConfiguration {
        const { labels, values } = this.processCountData(item, item.yField || 'Field');
        return {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: item.name,
                    data: values,
                    backgroundColor: this.palette[0],
                    borderRadius: 6,
                }]
            },
            options: this.getCommonOptions(item, 'y', 'Count', item.yField || 'Field')
        };
    }

    private getColumnConfig(item: ChartItem): ChartConfiguration {
        const { labels, values } = this.processCountData(item, item.xField || 'Field');
        return {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: item.name,
                    data: values,
                    backgroundColor: this.palette[0],
                    borderRadius: 6,
                }]
            },
            options: this.getCommonOptions(item, 'x', item.xField || 'Field', 'Count')
        };
    }

    private getLineConfig(item: ChartItem): ChartConfiguration {
        const { labels, values } = this.processXYData(item);
        return {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: item.name,
                    data: values,
                    borderColor: this.palette[0],
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    pointBackgroundColor: this.palette[0],
                    pointRadius: 4,
                    borderWidth: 3
                }]
            },
            options: this.getCommonOptions(item, 'x')
        };
    }

    private getAreaConfig(item: ChartItem): ChartConfiguration {
        const { labels, values } = this.processXYData(item);
        return {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: item.name,
                    data: values,
                    borderColor: this.palette[0],
                    backgroundColor: `${this.palette[0]}33`, // 20% opacity
                    fill: true,
                    tension: 0.4,
                    pointRadius: 2
                }]
            },
            options: this.getCommonOptions(item, 'x')
        };
    }

    private getPieConfig(item: ChartItem): ChartConfiguration {
        const { labels, values } = this.processXYData(item);
        return {
            type: 'pie',
            data: {
                labels,
                datasets: [{
                    data: values,
                    backgroundColor: this.palette,
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: false,
                animation: false,
                plugins: {
                    legend: { display: true, position: 'right', labels: { boxWidth: 12, padding: 15, font: { size: 11 } } },
                    title: { display: true, text: item.name, font: { size: 16, weight: 'bold' }, padding: { bottom: 10 } }
                }
            } as any
        };
    }

    private getStackedBarConfig(item: ChartItem): ChartConfiguration {
        const categoryField = item.yField || '';
        const groupField = item.xField || '';
        const datasets = this.processStackedData(item, categoryField, groupField);
        const labels = datasets.length > 0 ? datasets[0].labels : [];

        const options = this.getCommonOptions(item, 'y', 'Count', categoryField || 'Category');

        return {
            type: 'bar',
            data: { labels, datasets: datasets.map(d => ({ ...d, labels: undefined })) },
            options: {
                ...options,
                plugins: {
                    ...options.plugins,
                    legend: { display: datasets.length > 1, position: 'top' }
                },
                scales: {
                    x: {
                        stacked: true,
                        beginAtZero: true,
                        grid: { display: true, color: '#f0f0f0' },
                        ticks: { stepSize: 1, color: '#455a64' },
                        title: { display: true, text: 'Count', font: { size: 14, weight: 'bold' }, color: 'navy' }
                    },
                    y: {
                        stacked: true,
                        grid: { display: false },
                        ticks: { display: true, color: '#455a64' },
                        title: { display: true, text: categoryField || 'Category', font: { size: 14, weight: 'bold' }, color: 'navy' }
                    }
                }
            } as any
        };
    }

    private getStackedColumnConfig(item: ChartItem): ChartConfiguration {
        const categoryField = item.xField || '';
        const groupField = item.yField || '';
        const datasets = this.processStackedData(item, categoryField, groupField);
        const labels = datasets.length > 0 ? datasets[0].labels : [];

        const options = this.getCommonOptions(item, 'x', categoryField || 'Category', 'Count');

        return {
            type: 'bar',
            data: { labels, datasets: datasets.map(d => ({ ...d, labels: undefined })) },
            options: {
                ...options,
                plugins: {
                    ...options.plugins,
                    legend: { display: datasets.length > 1, position: 'top' }
                },
                scales: {
                    x: {
                        stacked: true,
                        grid: { display: false },
                        ticks: { color: '#455a64' },
                        title: { display: true, text: categoryField || 'Category', font: { size: 14, weight: 'bold' }, color: 'navy' }
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true,
                        grid: { display: true, color: '#f0f0f0' },
                        ticks: { stepSize: 1, color: '#455a64' },
                        title: { display: true, text: 'Count', font: { size: 14, weight: 'bold' }, color: 'navy' }
                    }
                }
            } as any
        };
    }

    private getStackedAreaConfig(item: ChartItem): ChartConfiguration {
        const { labels, values } = this.processXYData(item); // Simple implementation for now
        return {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: item.name,
                    data: values,
                    borderColor: this.palette[0],
                    backgroundColor: `${this.palette[0]}55`,
                    fill: 'origin',
                    tension: 0.4
                }]
            },
            options: {
                ...this.getCommonOptions(item, 'x'),
                scales: {
                    y: { stacked: true, beginAtZero: true }
                }
            } as any
        };
    }

    private getCommonOptions(item: ChartItem, indexAxis: 'x' | 'y', xLabel?: string, yLabel?: string): any {
        return {
            indexAxis,
            responsive: false,
            animation: false,
            plugins: {
                legend: { display: false },
                title: {
                    display: true,
                    text: item.name,
                    color: '#1a237e',
                    font: { size: 18, weight: 'bold', family: 'Inter' },
                    padding: { top: 10, bottom: 20 }
                }
            },
            scales: {
                x: {
                    grid: { display: indexAxis === 'y', color: '#f0f0f0' },
                    ticks: {
                        display: true,
                        font: { size: 12 },
                        color: '#455a64',
                        autoSkip: false
                    },
                    title: xLabel ? { display: true, text: xLabel, font: { size: 14, weight: 'bold' }, color: '#1a237e' } : undefined
                },
                y: {
                    grid: { display: indexAxis === 'x', color: '#f0f0f0' },
                    ticks: {
                        display: indexAxis === 'x', // Hide categories for bar charts
                        font: { size: 12 },
                        color: '#455a64',
                        autoSkip: false
                    },
                    title: yLabel ? { display: true, text: yLabel, font: { size: 14, weight: 'bold' }, color: '#1a237e' } : undefined
                }
            }
        };
    }

    private processCountData(item: ChartItem, dimField: string) {
        if (!item.data) return { labels: [], values: [] };
        const counts: Record<string, number> = {};
        item.data.forEach(d => {
            const val = String(d[dimField] || 'N/A');
            counts[val] = (counts[val] || 0) + 1;
        });
        const labels = Object.keys(counts).slice(0, 10);
        const values = labels.map(l => counts[l]);
        return { labels, values };
    }

    private processXYData(item: ChartItem) {
        if (!item.data) return { labels: [], values: [] };
        const xF = item.xField || '';
        const yF = item.yField || '';
        const labels = item.data.slice(0, 10).map(d => String(d[xF] || ''));
        const values = item.data.slice(0, 10).map(d => {
            const v = parseFloat(d[yF]);
            return isNaN(v) ? 0 : v;
        });
        return { labels, values };
    }

    private processStackedData(item: ChartItem, categoryField?: string, groupField?: string) {
        if (!item.data || !categoryField) return [];

        // Get unique categories (labels)
        const allCategories = [...new Set(item.data.map(d => String(d[categoryField] || 'N/A')))];
        const categories = allCategories.slice(0, 10);

        // Fallback: If no group field, show one "Total" stack
        if (!groupField) {
            return [{
                label: 'Total',
                labels: categories,
                data: categories.map(c => item.data!.filter(d => String(d[categoryField]) === c).length),
                backgroundColor: this.palette[0],
                borderRadius: 6,
                barThickness: 24
            }];
        }

        // Get unique groups (datasets)
        const allGroups = [...new Set(item.data.map(d => String(d[groupField] || 'N/A')))];
        const groups = allGroups.slice(0, 8);

        // Map groups into datasets using counting logic like the user's example
        return groups.map((g, idx) => ({
            label: g,
            labels: categories,
            data: categories.map(c =>
                item.data!.filter(d => String(d[categoryField]) === c && String(d[groupField]) === g).length
            ),
            backgroundColor: this.palette[idx % this.palette.length],
            borderRadius: 6,
            barThickness: 24,
            borderWidth: 1,
            borderColor: '#ffffff'
        }));
    }
}
