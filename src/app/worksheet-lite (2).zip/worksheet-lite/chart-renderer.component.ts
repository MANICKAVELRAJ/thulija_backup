import { Component, Input, ViewChild, ElementRef, AfterViewInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { ChartGenService, ChartItem } from './chart-gen.service';
import { Chart } from 'chart.js/auto';

@Component({
    selector: 'app-chart-renderer',
    templateUrl: './chart-renderer.component.html',
    styleUrls: ['./chart-renderer.component.css']
})
export class ChartRendererComponent implements AfterViewInit, OnChanges, OnDestroy {
    @Input() item!: ChartItem;
    @ViewChild('chartCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;

    private chartInstance: Chart | null = null;
    private resizeObserver: ResizeObserver | null = null;

    constructor(private chartGen: ChartGenService, private el: ElementRef) { }

    ngAfterViewInit(): void {
        if (this.item) {
            this.render();
            this.setupResizeObserver();
        }
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['item'] && !changes['item'].firstChange) {
            this.render();
        }
    }

    render(): void {
        if (!this.canvasRef || !this.item) return;

        // Destroy existing chart to prevent memory leaks and "Canvas is already in use" error
        if (this.chartInstance) {
            this.chartInstance.destroy();
            this.chartInstance = null;
        }

        // Delegate rendering to service
        this.chartInstance = this.chartGen.renderChart(this.item, this.canvasRef.nativeElement);
    }

    setupResizeObserver(): void {
        // Optional: Resizing logic if the container changes size
        this.resizeObserver = new ResizeObserver(() => {
            if (this.chartInstance) {
                this.chartInstance.resize();
            }
        });
        this.resizeObserver.observe(this.el.nativeElement);
    }

    ngOnDestroy(): void {
        if (this.chartInstance) {
            this.chartInstance.destroy();
        }
        if (this.resizeObserver) {
            this.resizeObserver.disconnect();
        }
    }
}
