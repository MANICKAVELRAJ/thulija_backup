import { Injectable } from '@angular/core';
import {
  Chart,
  registerables,
  ChartConfiguration,
  ChartDataset,
  TooltipItem
} from 'chart.js/auto';

Chart.register(...registerables);

/* ================================================================== */
/*  ChartItem                                                           */
/* ================================================================== */
export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  tableId?: number;
  tableName?: string;
  fields?: string[];   // dropdown list shown to user
  data?: any[];      // raw rows fetched for chosen page_id
  xField?: string;     // user-chosen X/category field
  yField?: string;     // user-chosen Y/value field
  valueField?: string;
  xFieldId?: number;
  yFieldId?: number;
  xFieldValue?: string;
  yFieldValue?: string;
}

/* ================================================================== */
/*  FieldKind — what kind of column each field is                       */
/*                                                                      */
/*  LABEL      → unique text per row  e.g. column_name, property_name  */
/*               Best use: X-axis label — each row = its own bar       */
/*                                                                      */
/*  CATEGORICAL→ few repeated values  e.g. data_type_id (1,2,8)        */
/*               hide (0/1), control_field_id                          */
/*               Best use: GROUP + COUNT occurrences per value          */
/*               Perfect for pie slices, stacked groups                 */
/*                                                                      */
/*  NUMERIC    → many distinct real numbers  e.g. display_width 6-92  */
/*               Best use: Y-axis real value (SUM / AVG)               */
/*                                                                      */
/*  SKIP       → constant, all-same, IDs, empty — useless for charts  */
/* ================================================================== */
export type FieldKind = 'label' | 'categorical' | 'numeric' | 'skip';

export interface FieldMeta {
  key: string;
  kind: FieldKind;
  unique: number;
  total: number;
  sampleVals: string[];
}

export interface SmartAnalysis {
  allMeta: FieldMeta[];
  labelFields: string[];   // HIGH cardinality text  -> X-axis row labels
  catFields: string[];   // LOW  cardinality any   -> COUNT grouping / pie
  numFields: string[];   // HIGH cardinality num   -> Y-axis numeric measure
  usableFields: string[];   // labelFields + catFields + numFields (for dropdown)
  defaultX: string;     // recommended X for bar/column/line
  defaultCatX: string;     // recommended X for pie (categorical)
  defaultY: string;     // recommended Y (numeric) or '' = use count
}

/* ================================================================== */
/*  data_type_id number -> readable name                               */
/* ================================================================== */
const DTYPE: Record<string, string> = {
  '1': 'Integer', '2': 'Text', '3': 'Boolean', '4': 'Decimal',
  '6': 'Decimal', '7': 'Currency', '8': 'DateTime', '9': 'Time',
  '10': 'URL', '11': 'Date', 'null': 'Reference', 'undefined': 'Reference'
};

/* ================================================================== */
/*  SmartFieldAnalyser                                                  */
/*  Looks at the ACTUAL VALUES in every column and decides:            */
/*    - Is this a label field? (unique text per row)                   */
/*    - Is this categorical? (few repeated values -> count them)       */
/*    - Is this numeric? (many distinct numbers -> use as measure)     */
/*    - Should we skip? (constant, monotone ID, empty)                 */
/* ================================================================== */
export class SmartFieldAnalyser {

  private static readonly ALWAYS_SKIP = new Set([
    'project_id', 'createdby', 'lastmodifiedby'
  ]);

  private static readonly ALWAYS_LABEL = new Set([
    'column_name', 'property_name'
  ]);

  static analyse(rows: any[]): SmartAnalysis {
    if (!rows?.length) {
      return {
        allMeta: [], labelFields: [], catFields: [],
        numFields: [], usableFields: [],
        defaultX: '', defaultCatX: '', defaultY: ''
      };
    }

    const allKeys = new Set<string>();
    rows.forEach(r => Object.keys(r).forEach(k => allKeys.add(k)));
    const keys = Array.from(allKeys).filter(k => !this.ALWAYS_SKIP.has(k));
    const meta: FieldMeta[] = [];

    for (const key of keys) {
      const nonNull = rows
        .map(r => r[key])
        .filter(v => v !== null && v !== undefined && v !== '');

      if (!nonNull.length) {
        meta.push({ key, kind: 'skip', unique: 0, total: 0, sampleVals: [] });
        continue;
      }

      const strVals = nonNull.map(String);
      const uniqSet = new Set(strVals);
      const unique = uniqSet.size;
      const total = nonNull.length;
      const ratio = unique / total;
      const numVals = nonNull.map(v => parseFloat(String(v)));
      const allNum = numVals.every(v => !isNaN(v));
      const sampleVals = [...uniqSet].slice(0, 5);

      // Force label fields — always treat as row names
      if (this.ALWAYS_LABEL.has(key)) {
        meta.push({ key, kind: 'label', unique, total, sampleVals }); continue;
      }
      // Constant value across all rows — treat as categorical
      if (unique <= 1) {
        meta.push({ key, kind: 'categorical', unique, total, sampleVals }); continue;
      }
      // Monotone unique integer IDs — treat as numeric
      if (allNum && ratio > 0.95 && unique > 10) {
        meta.push({ key, kind: 'numeric', unique, total, sampleVals }); continue;
      }

      if (allNum) {
        // Low-cardinality numeric (<=15 distinct): code IDs like data_type_id=1,2,8
        // -> COUNT per value
        if (unique <= 15) {
          meta.push({ key, kind: 'categorical', unique, total, sampleVals });
        } else {
          // High-cardinality numeric -> real measurements -> Y axis value
          meta.push({ key, kind: 'numeric', unique, total, sampleVals });
        }
      } else {
        // Text field
        if (ratio > 0.7) {
          // Mostly unique -> label (row name) -> X axis
          meta.push({ key, kind: 'label', unique, total, sampleVals });
        } else {
          // Repeated text -> categorical -> COUNT grouping
          meta.push({ key, kind: 'categorical', unique, total, sampleVals });
        }
      }
    }

    const labelFields = meta.filter(m => m.kind === 'label').map(m => m.key);
    const catFields = meta.filter(m => m.kind === 'categorical').map(m => m.key);
    const numFields = meta.filter(m => m.kind === 'numeric').map(m => m.key);
    const usableFields = keys.sort();

    const LABEL_PRIO = ['column_name', 'property_name'];
    const defaultX =
      LABEL_PRIO.find(k => labelFields.includes(k)) ??
      labelFields[0] ?? catFields[0] ?? '';

    const CAT_PRIO = ['data_type_id', 'control_field_id', 'hide'];
    const defaultCatX =
      CAT_PRIO.find(k => catFields.includes(k)) ??
      catFields[0] ?? defaultX;

    const NUM_PRIO = ['display_width'];
    const defaultY =
      NUM_PRIO.find(k => numFields.includes(k)) ??
      numFields[0] ?? '';

    return { allMeta: meta, labelFields, catFields, numFields, usableFields, defaultX, defaultCatX, defaultY };
  }

  static axisLabel(key: string): string {
    const MAP: Record<string, string> = {
      column_name: 'Column Name', property_name: 'Property',
      data_type_id: 'Field Type', display_width: 'Display Width',
      hide: 'Hidden', control_field_id: 'Control Type',
      page_id: 'Page', join_column_module_id: 'Join Module',
      join_column_page_id: 'Join Page'
    };
    return MAP[key] ?? key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }

  static cellDisplay(key: string, val: any): string {
    if (val === null || val === undefined || val === '') return 'N/A';
    if (key === 'data_type_id') return DTYPE[String(val)] ?? 'Type ' + val;
    return String(val);
  }
}

/* ================================================================== */
/*  Design tokens                                                       */
/* ================================================================== */
const FONT = "'Inter','Roboto',sans-serif";
const C_TITLE = '#1a237e';
const C_LABEL = '#546e7a';
const C_GRID = '#eceff1';
const C_AXIS = '#90a4ae';
const PALETTE = [
  '#1a73e8', '#34a853', '#fbbc05', '#ea4335',
  '#46bdc6', '#ff6d01', '#673ab7', '#9c27b0',
  '#0097a7', '#795548', '#607d8b'
];

function mkTooltip(cb?: (ctx: TooltipItem<any>) => string) {
  return {
    enabled: true, backgroundColor: 'rgba(26,35,126,0.93)',
    titleColor: '#fff', bodyColor: '#c5cae9',
    borderColor: '#3949ab', borderWidth: 1, padding: 10, cornerRadius: 8,
    titleFont: { family: FONT, size: 12, weight: 'bold' as const },
    bodyFont: { family: FONT, size: 11 },
    callbacks: {
      label: cb ?? ((ctx: TooltipItem<any>) => {
        const v = ctx.parsed?.y ?? ctx.parsed?.r ?? ctx.formattedValue;
        return `  ${ctx.dataset.label ?? 'Value'}: ${Number(v).toLocaleString()}`;
      })
    }
  };
}
function mkTitle(t: string) {
  return {
    display: true, text: t, color: C_TITLE,
    font: { family: FONT, size: 14, weight: 'bold' as const }, padding: { top: 6, bottom: 8 }
  };
}
function mkLegend(show = false) {
  return {
    display: show, position: 'top' as const,
    labels: { font: { family: FONT, size: 11 }, color: C_LABEL, boxWidth: 12, padding: 14, usePointStyle: true }
  };
}
function mkLinear(label: string, stacked = false) {
  return {
    stacked, beginAtZero: true, border: { color: C_AXIS }, grid: { color: C_GRID, lineWidth: 1 },
    ticks: {
      color: C_LABEL, font: { family: FONT, size: 11 }, maxTicksLimit: 8, padding: 4,
      callback: (v: any) => Number.isInteger(+v) ? +v : +(+v).toFixed(1)
    },
    title: {
      display: !!label, text: label, color: C_TITLE,
      font: { family: FONT, size: 12, weight: 'bold' as const }, padding: { top: 4, bottom: 4 }
    }
  };
}
function mkCategory(label: string, stacked = false) {
  return {
    stacked, border: { color: C_AXIS }, grid: { display: false },
    ticks: {
      color: C_LABEL, font: { family: FONT, size: 11 },
      maxRotation: 40, minRotation: 0, autoSkip: true, maxTicksLimit: 15, padding: 4
    },
    title: {
      display: !!label, text: label, color: C_TITLE,
      font: { family: FONT, size: 12, weight: 'bold' as const }, padding: { top: 4, bottom: 4 }
    }
  };
}
function baseOpts(name: string): any {
  return {
    responsive: true, maintainAspectRatio: false,
    animation: { duration: 450, easing: 'easeOutQuart' },
    layout: { padding: { top: 4, right: 14, bottom: 4, left: 4 } },
    plugins: { title: mkTitle(name), legend: mkLegend(false), tooltip: mkTooltip() }
  };
}

/* ================================================================== */
/*  ChartGenService                                                     */
/* ================================================================== */
@Injectable({ providedIn: 'root' })
export class ChartGenService {

  constructor() { }

  renderChart(item: ChartItem, canvas: HTMLCanvasElement): Chart | null {
    const ctx = canvas.getContext('2d');
    if (!ctx || !item?.data?.length) return null;

    const sa = SmartFieldAnalyser.analyse(item.data);
    const { xF, yF } = this.resolveXY(item, sa);

    let cfg: ChartConfiguration;
    switch (item.type) {
      case 'bar': cfg = this.buildBar(item, xF, yF, sa); break;
      case 'column': cfg = this.buildColumn(item, xF, yF, sa); break;
      case 'line': cfg = this.buildLine(item, xF, yF, sa); break;
      case 'area': cfg = this.buildArea(item, xF, yF, sa); break;
      case 'pie': cfg = this.buildPie(item, xF, yF, sa); break;
      case 'doughnut': cfg = this.buildDoughnut(item, xF, yF, sa); break;
      case 'stackedBar': cfg = this.buildStackedBar(item, xF, yF, sa); break;
      case 'stackedColumn': cfg = this.buildStackedColumn(item, xF, yF, sa); break;
      case 'stackedArea': cfg = this.buildStackedArea(item, xF, yF, sa); break;
      default: return null;
    }
    return new Chart(ctx, cfg);
  }

  /* ----------------------------------------------------------------
     resolveXY — user explicit choice wins, else smart default
  ---------------------------------------------------------------- */
  private resolveXY(item: ChartItem, sa: SmartAnalysis): { xF: string; yF: string } {
    const userX = item.xField?.trim() || '';
    const userY = item.yField?.trim() || '';
    switch (item.type) {
      case 'bar':
      case 'column':
      case 'line':
      case 'area':
        return { xF: userX || sa.defaultX, yF: userY || sa.defaultY };
      case 'pie':
      case 'doughnut':
        return { xF: userX || sa.defaultCatX || sa.defaultX, yF: '' };
      case 'stackedBar':
      case 'stackedColumn':
      case 'stackedArea':
        return {
          xF: userX || sa.defaultCatX || sa.defaultX,
          yF: userY || sa.catFields[1] || ''
        };
      default:
        return { xF: userX || sa.defaultX, yF: userY || sa.defaultY };
    }
  }

  /* ================================================================
     SMART DATA BUILDER — core logic

     MODE A: xF=LABEL + yF=NUMERIC  -> one bar per row, height = actual value
     MODE B: xF=LABEL + yF=empty    -> one bar per row, height = 1 (all equal)
     MODE C: xF=CATEGORICAL + yF=empty -> COUNT rows per unique category value
     MODE D: xF=CATEGORICAL + yF=NUMERIC -> SUM numeric grouped by category
  ================================================================ */
  private smartData(
    rows: any[], xF: string, yF: string, sa: SmartAnalysis, limit = 20
  ): { labels: string[]; values: number[]; yLabel: string } {

    if (!rows?.length || !xF) return { labels: [], values: [], yLabel: '' };

    const xMeta = sa.allMeta.find(m => m.key === xF);
    const yMeta = yF ? sa.allMeta.find(m => m.key === yF) : null;
    const xIsLabel = xMeta?.kind === 'label';
    const yIsNum = yMeta?.kind === 'numeric';

    /* MODES A & B: X is label -> one entry per row */
    if (xIsLabel) {
      const limited = rows.slice(0, limit);
      const labels = limited.map(r => SmartFieldAnalyser.cellDisplay(xF, r[xF]));
      if (yIsNum && yF) {
        // MODE A: real numeric Y
        const values = limited.map(r => {
          const v = parseFloat(String(r[yF] ?? '0'));
          return isNaN(v) ? 0 : v;
        });
        return { labels, values, yLabel: SmartFieldAnalyser.axisLabel(yF) };
      } else {
        // MODE B: equal height = 1 for all
        return { labels, values: limited.map(() => 1), yLabel: 'Fields' };
      }
    }

    /* MODES C & D: X is categorical -> bucket + count/sum */
    const buckets = new Map<string, number[]>();
    for (const row of rows) {
      const lbl = SmartFieldAnalyser.cellDisplay(xF, row[xF]);
      if (!buckets.has(lbl)) buckets.set(lbl, []);
      if (yIsNum && yF) {
        const v = parseFloat(String(row[yF] ?? '0'));
        buckets.get(lbl)!.push(isNaN(v) ? 0 : v);
      } else {
        buckets.get(lbl)!.push(1);
      }
    }

    const entries = [...buckets.entries()]
      .map(([label, nums]) => ({ label, value: nums.reduce((a, b) => a + b, 0) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, limit);

    return {
      labels: entries.map(e => e.label),
      values: entries.map(e => e.value),
      yLabel: yIsNum && yF
        ? `Sum of ${SmartFieldAnalyser.axisLabel(yF)}`
        : 'Count'
    };
  }

  /* ================================================================ BAR */
  private buildBar(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, values, yLabel } = this.smartData(item.data!, xF, yF, sa, 20);
    const xLabel = SmartFieldAnalyser.axisLabel(xF);
    return {
      type: 'bar', data: {
        labels, datasets: [{
          label: yLabel, data: values,
          backgroundColor: labels.map((_, i) => PALETTE[i % PALETTE.length] + 'cc'),
          borderColor: labels.map((_, i) => PALETTE[i % PALETTE.length]),
          borderWidth: 1, borderRadius: { topRight: 6, bottomRight: 6 },
          borderSkipped: 'start', barPercentage: 0.72, categoryPercentage: 0.85
        }]
      },
      options: {
        ...baseOpts(item.name), indexAxis: 'y',
        plugins: {
          ...baseOpts(item.name).plugins,
          tooltip: mkTooltip(ctx => `  ${yLabel}: ${Number(values[ctx.dataIndex]).toLocaleString()}`)
        },
        scales: { x: mkLinear(yLabel), y: mkCategory(xLabel) }
      } as any
    };
  }

  /* ================================================================ COLUMN */
  private buildColumn(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, values, yLabel } = this.smartData(item.data!, xF, yF, sa, 20);
    const xLabel = SmartFieldAnalyser.axisLabel(xF);
    return {
      type: 'bar', data: {
        labels, datasets: [{
          label: yLabel, data: values,
          backgroundColor: labels.map((_, i) => PALETTE[i % PALETTE.length] + 'cc'),
          borderColor: labels.map((_, i) => PALETTE[i % PALETTE.length]),
          borderWidth: 1, borderRadius: { topLeft: 6, topRight: 6 },
          borderSkipped: 'bottom', barPercentage: 0.72, categoryPercentage: 0.85
        }]
      },
      options: {
        ...baseOpts(item.name), indexAxis: 'x',
        plugins: {
          ...baseOpts(item.name).plugins,
          tooltip: mkTooltip(ctx => `  ${yLabel}: ${Number(values[ctx.dataIndex]).toLocaleString()}`)
        },
        scales: { x: mkCategory(xLabel), y: mkLinear(yLabel) }
      } as any
    };
  }

  /* ================================================================ LINE */
  private buildLine(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, values, yLabel } = this.smartData(item.data!, xF, yF, sa, 25);
    const xLabel = SmartFieldAnalyser.axisLabel(xF);
    return {
      type: 'line', data: {
        labels, datasets: [{
          label: yLabel, data: values, borderColor: PALETTE[0],
          backgroundColor: PALETTE[0] + '22', borderWidth: 2.5, tension: 0.35,
          pointBackgroundColor: PALETTE[0], pointBorderColor: '#fff',
          pointBorderWidth: 2, pointRadius: 4, pointHoverRadius: 6, fill: false
        }]
      },
      options: {
        ...baseOpts(item.name),
        scales: { x: mkCategory(xLabel), y: mkLinear(yLabel) }
      } as any
    };
  }

  /* ================================================================ AREA */
  private buildArea(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, values, yLabel } = this.smartData(item.data!, xF, yF, sa, 25);
    const xLabel = SmartFieldAnalyser.axisLabel(xF);
    return {
      type: 'line', data: {
        labels, datasets: [{
          label: yLabel, data: values, borderColor: PALETTE[0],
          backgroundColor: PALETTE[0] + '33', borderWidth: 2, tension: 0.4,
          pointBackgroundColor: PALETTE[0], pointBorderColor: '#fff',
          pointBorderWidth: 2, pointRadius: 3, pointHoverRadius: 5, fill: 'origin'
        }]
      },
      options: {
        ...baseOpts(item.name),
        scales: { x: mkCategory(xLabel), y: mkLinear(yLabel) }
      } as any
    };
  }

  /* ================================================================ PIE */
  private buildPie(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, values } = this.smartData(item.data!, xF, yF, sa, 12);
    const total = values.reduce((a, b) => a + b, 0);
    return {
      type: 'pie', data: {
        labels, datasets: [{
          data: values, backgroundColor: PALETTE.map(c => c + 'dd'),
          borderColor: '#fff', borderWidth: 2, hoverOffset: 8
        }]
      },
      options: {
        ...baseOpts(item.name), plugins: {
          title: mkTitle(item.name),
          legend: {
            display: true, position: 'right' as const,
            labels: {
              font: { family: FONT, size: 11 }, color: C_LABEL,
              boxWidth: 12, padding: 10, usePointStyle: true
            }
          },
          tooltip: mkTooltip(ctx => {
            const v = values[ctx.dataIndex];
            const pct = total ? ((v / total) * 100).toFixed(1) : '0';
            return `  ${labels[ctx.dataIndex]}: ${v} (${pct}%)`;
          })
        }
      } as any
    };
  }

  /* ================================================================ DOUGHNUT */
  private buildDoughnut(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, values } = this.smartData(item.data!, xF, yF, sa, 12);
    const total = values.reduce((a, b) => a + b, 0);

    // Build a rich gradient palette for doughnut slices
    const bgColors  = PALETTE.map(c => c + 'dd');
    const hvrColors = PALETTE.map(c => c);

    return {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor:      bgColors,
          hoverBackgroundColor: hvrColors,
          borderColor:          '#ffffff',
          borderWidth:          3,
          hoverBorderWidth:     2,
          hoverOffset:          12
        }]
      },
      options: {
        ...baseOpts(item.name),
        cutout: '62%',           // doughnut hole size
        rotation: -90,           // start from top
        plugins: {
          title: mkTitle(item.name),
          legend: {
            display: true,
            position: 'right' as const,
            labels: {
              font: { family: FONT, size: 11 },
              color: C_LABEL,
              boxWidth: 12,
              padding: 10,
              usePointStyle: true,
              pointStyleWidth: 10
            }
          },
          tooltip: mkTooltip(ctx => {
            const v   = values[ctx.dataIndex];
            const pct = total ? ((v / total) * 100).toFixed(1) : '0';
            return `  ${labels[ctx.dataIndex]}: ${v.toLocaleString()} (${pct}%)`;
          })
        }
      } as any
    };
  }

  /* ================================================================ STACKED BAR */
  private buildStackedBar(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, datasets } = this.buildStackedData(item.data!, xF, yF);
    const catLabel = SmartFieldAnalyser.axisLabel(xF);
    return {
      type: 'bar', data: { labels, datasets },
      options: {
        ...baseOpts(item.name), indexAxis: 'y',
        plugins: { ...baseOpts(item.name).plugins, legend: mkLegend(datasets.length > 1) },
        scales: { x: { ...mkLinear('Count'), stacked: true }, y: { ...mkCategory(catLabel), stacked: true } }
      } as any
    };
  }

  /* ================================================================ STACKED COLUMN */
  private buildStackedColumn(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, datasets } = this.buildStackedData(item.data!, xF, yF);
    const catLabel = SmartFieldAnalyser.axisLabel(xF);
    return {
      type: 'bar', data: { labels, datasets },
      options: {
        ...baseOpts(item.name), indexAxis: 'x',
        plugins: { ...baseOpts(item.name).plugins, legend: mkLegend(datasets.length > 1) },
        scales: { x: { ...mkCategory(catLabel), stacked: true }, y: { ...mkLinear('Count'), stacked: true } }
      } as any
    };
  }

  /* ================================================================ STACKED AREA */
  private buildStackedArea(item: ChartItem, xF: string, yF: string, sa: SmartAnalysis): ChartConfiguration {
    const { labels, datasets } = this.buildStackedData(item.data!, xF, yF);
    const catLabel = SmartFieldAnalyser.axisLabel(xF);
    const aDs = datasets.map((ds: any) => ({
      ...ds, fill: true, tension: 0.4, borderWidth: 2,
      type: 'line', pointRadius: 2, pointHoverRadius: 4
    }));
    return {
      type: 'line', data: { labels, datasets: aDs },
      options: {
        ...baseOpts(item.name),
        plugins: { ...baseOpts(item.name).plugins, legend: mkLegend(aDs.length > 1) },
        scales: { x: mkCategory(catLabel), y: { ...mkLinear('Count'), stacked: true } }
      } as any
    };
  }

  /* ================================================================ STACKED DATA */
  private buildStackedData(rows: any[], catField: string, groupField: string) {
    if (!rows?.length || !catField) return { labels: [], datasets: [] };

    const allCats = [...new Set(
      rows.map(r => SmartFieldAnalyser.cellDisplay(catField, r[catField]))
    )].slice(0, 12);

    if (!groupField) {
      return {
        labels: allCats, datasets: [{
          label: 'Count',
          data: allCats.map(c => rows.filter(r =>
            SmartFieldAnalyser.cellDisplay(catField, r[catField]) === c).length),
          backgroundColor: PALETTE[0] + 'cc', borderColor: PALETTE[0],
          borderWidth: 1, borderRadius: 4, barPercentage: 0.75
        } as any]
      };
    }

    const allGroups = [...new Set(
      rows.map(r => SmartFieldAnalyser.cellDisplay(groupField, r[groupField]))
    )].slice(0, 8);

    const datasets: ChartDataset[] = allGroups.map((g, i) => ({
      label: g,
      data: allCats.map(c => rows.filter(r =>
        SmartFieldAnalyser.cellDisplay(catField, r[catField]) === c &&
        SmartFieldAnalyser.cellDisplay(groupField, r[groupField]) === g
      ).length),
      backgroundColor: PALETTE[i % PALETTE.length] + 'cc',
      borderColor: PALETTE[i % PALETTE.length],
      borderWidth: 1, borderRadius: 3, barPercentage: 0.8
    } as any));

    return { labels: allCats, datasets };
  }
}
