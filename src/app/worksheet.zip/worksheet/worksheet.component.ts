import { Component } from '@angular/core';

@Component({
  selector: 'app-worksheet',
  templateUrl: './worksheet.component.html',
  styleUrl: './worksheet.component.css'
})
export class WorksheetComponent {

}
