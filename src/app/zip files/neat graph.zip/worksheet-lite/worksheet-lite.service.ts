import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as XLSX from 'xlsx';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs';
import { Chart, registerables } from 'chart.js/auto';

Chart.register(...registerables);

/* ================= CHART ================= */
export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  /* ===== DATA BINDING ===== */
  /* 🔥 DATA */
  tableId?: number;        // 🔥 ADD THIS
  tableName?: string;      // appendixe
  fields?: string[];
  data?: any[];
  valueField?: string
  xField?: string;
  yField?: string;


  xFieldId?: number;
  yFieldId?: number;

  xFieldValue?: string;
  yFieldValue?: string;
  realGraphSvg?: SafeHtml; // 🔥 Dynamic SVG
}

/* ================= CHART REQUIREMENTS ================= */
export interface ChartRequirements {
  selectableX: boolean;
  selectableY: boolean;
  xLabel: string;
  yLabel: string;
}
/* ================= PAGE ================= */
export interface PageItem {
  id: number;
  page_name: string;
  table_name: string;
}


@Injectable({ providedIn: 'root' })
export class WorksheetLiteService {

  /* ================= DATA ================= */
  chartTypes: ChartItem[] = [];
  canvasCharts: ChartItem[] = [];

  /* ================= WORKFLOW ================= */
  private workflowFieldsSubject = new BehaviorSubject<string[]>([]);
  workflowFields$ = this.workflowFieldsSubject.asObservable();

  /* ================= FIELDS.JSON ================= */
  private fieldsSubject = new BehaviorSubject<any[]>([]);
  fields$ = this.fieldsSubject.asObservable();

  get allFields(): any[] {
    return this.fieldsSubject.value;
  }

  /* ================= CANVAS ================= */
  nextId = 1000;
  zIndexCounter = 10;

  canvasEl!: HTMLElement;
  movingIndex: number | null = null;
  offsetX = 0;
  offsetY = 0;

  chartRequirementsMap: Record<string, ChartRequirements> = {
    bar: { selectableX: false, selectableY: true, xLabel: 'Count', yLabel: 'Field' },
    column: { selectableX: true, selectableY: false, xLabel: 'Field', yLabel: 'Count' },
    line: { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' },
    area: { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' },
    pie: { selectableX: true, selectableY: true, xLabel: 'Category', yLabel: 'Value' },
    stackedBar: { selectableX: true, selectableY: true, xLabel: 'Group By', yLabel: 'Category' },
    stackedColumn: { selectableX: true, selectableY: true, xLabel: 'Category', yLabel: 'Group By' },
    stackedArea: { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' },
  };

  getChartRequirements(type: string): ChartRequirements {
    return this.chartRequirementsMap[type] || { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' };
  }

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer
  ) {
    this.loadWorkflow();
    this.loadFields();
    this.loadPages();
  }

  /* ================= INIT ================= */
  initCanvas(el: HTMLElement): void {
    this.canvasEl = el;
  }
  /* ================= LOAD FIELDS.JSON ================= */
  loadFields(): void {
    this.http.get<any[]>('assets/fields.json')
      .subscribe(res => {
        if (Array.isArray(res)) {
          this.fieldsSubject.next(res);
          console.log('Fields.json:', res);
        } else {
          this.fieldsSubject.next([]);
        }
      });
  }

  /* ================= LOAD PAGES.JSON ================= */
  private pagesSubject = new BehaviorSubject<PageItem[]>([]);
  pages$ = this.pagesSubject.asObservable();

  loadPages(): void {
    this.http.get<PageItem[]>('assets/pages.json')
      .subscribe(res => {
        if (Array.isArray(res) && res.length > 0) {
          this.pagesSubject.next(res);
          console.log('Pages.json loaded:', res);
        } else {
          this.pagesSubject.next([]);
        }
      });
  }


  /* ================= LOAD CHARTS ================= */
  loadCharts(): Promise<ChartItem[]> {
    return this.http
      .get<ChartItem[]>('assets/chart.json')
      .toPromise()
      .then(res => {
        this.chartTypes = res || [];
        return this.chartTypes;
      });
  }

  /* ================= LOAD WORKFLOW (FIXED) ================= */
  loadWorkflow(): void {
    this.http.get<any[]>('assets/workflowprocess.json')
      .subscribe(res => {

        if (!Array.isArray(res) || res.length === 0) {
          this.workflowFieldsSubject.next([]);
          return;
        }

        // 🔥 extract keys from first object
        const fields = Object.keys(res[0]);

        this.workflowFieldsSubject.next(fields);
        console.log('Workflow Fields:', fields);
      });
  }
  /* ================= DROP ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    if (event.previousContainer.id !== 'chartList') return;

    const draggedChart = event.item.data as ChartItem;
    const rect = this.canvasEl.getBoundingClientRect();
    const mouse = event.event as MouseEvent;

    const width = 400; // Updated to match standard chart size for neatness
    const height = 300;

    let x = mouse.clientX - rect.left - width / 2;
    let y = mouse.clientY - rect.top - height / 2;

    [x, y] = this.findFreePosition(x, y, width, height);

    this.canvasCharts.push({
      ...draggedChart,
      id: this.nextId++,
      x,
      y,
      width,
      height,
      zIndex: ++this.zIndexCounter
    });
  }


  /* ================= OVERLAP ================= */
  findFreePosition(
    x: number,
    y: number,
    width: number,
    height: number,
    ignoreIndex: number | null = null
  ): [number, number] {

    const padding = 16;

    x = Math.max(0, Math.min(x, this.canvasEl.clientWidth - width));
    y = Math.max(0, Math.min(y, this.canvasEl.clientHeight - height));

    for (let i = 0; i < 200; i++) {
      let overlap = false;

      for (let j = 0; j < this.canvasCharts.length; j++) {
        if (ignoreIndex === j) continue;

        const c = this.canvasCharts[j];
        const hit = !(
          x + width + padding < c.x! ||
          x > c.x! + c.width! + padding ||
          y + height + padding < c.y! ||
          y > c.y! + c.height! + padding
        );

        if (hit) {
          overlap = true;
          x += padding;
          y += padding;
          break;
        }
      }
      if (!overlap) break;
    }
    return [x, y];
  }

  /* ================= MOVE ================= */
  startMove(event: MouseEvent, index: number): void {
    this.movingIndex = index;
    const item = this.canvasCharts[index];
    item.zIndex = ++this.zIndexCounter;
    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  moveItem(event: MouseEvent): void {
    if (this.movingIndex === null) return;

    const rect = this.canvasEl.getBoundingClientRect();
    const item = this.canvasCharts[this.movingIndex];

    item.x = Math.max(
      0,
      Math.min(
        event.clientX - rect.left - this.offsetX,
        this.canvasEl.clientWidth - item.width!
      )
    );

    item.y = Math.max(
      0,
      Math.min(
        event.clientY - rect.top - this.offsetY,
        this.canvasEl.clientHeight - item.height!
      )
    );
  }

  stopMove(): void {
    if (this.movingIndex === null) return;

    const item = this.canvasCharts[this.movingIndex];
    const [x, y] = this.findFreePosition(
      item.x!,
      item.y!,
      item.width!,
      item.height!,
      this.movingIndex
    );

    item.x = x;
    item.y = y;
    this.movingIndex = null;
  }

  /* ================= SVG MAP ================= */
  chartSvgMap: Record<string, string> = {

    bar: `
    <svg viewBox="0 0 24 24">
      <rect x="2" y="2" width="21" height="6" fill="#1e88e5"/>
      <rect x="2" y="10" width="15" height="6" fill="#1e88e5"/>
      <rect x="2" y="18" width="9" height="6" fill="#1e88e5"/>
    </svg>
`,

    column: `
    <svg viewBox="0 0 24 24">
      <rect x="2" y="3" width="6" height="21" fill="#1e88e5"/>
      <rect x="10" y="9" width="6" height="15" fill="#1e88e5"/>
      <rect x="18" y="15" width="6" height="9" fill="#1e88e5"/>
    </svg>
`,

    stackedBar: `
    <svg viewBox="0 0 24 24">
      <rect x="0" y="2" width="5" height="4" fill="#1565c0"/>
      <rect x="5" y="2" width="6" height="4" fill="#1e88e5"/>
      <rect x="11" y="2" width="7" height="4" fill="#42a5f5"/>

      <rect x="0" y="8" width="10" height="4" fill="#1565c0"/>
      <rect x="10" y="8" width="8" height="4" fill="#1e88e5"/>
      <rect x="18" y="8" width="6" height="4" fill="#42a5f5"/>

      <rect x="0" y="14" width="6" height="4" fill="#1565c0"/>
      <rect x="6" y="14" width="9" height="4" fill="#1e88e5"/>
      <rect x="15" y="14" width="6" height="4" fill="#42a5f5"/>
  </svg>`,

    stackedColumn: `
    <svg viewBox="0 0 24 24">
      <rect x="2" y="19" width="4" height="5" fill="#1565c0"/>
      <rect x="2" y="13" width="4" height="6" fill="#1e88e5"/>
      <rect x="2" y="6" width="4" height="7" fill="#42a5f5"/>

      <rect x="8" y="14" width="4" height="10" fill="#1565c0"/>
      <rect x="8" y="6" width="4" height="8" fill="#1e88e5"/>
      <rect x="8" y="0" width="4" height="6" fill="#42a5f5"/>

      <rect x="14" y="18" width="4" height="6" fill="#1565c0"/>
      <rect x="14" y="9" width="4" height="9" fill="#1e88e5"/>
      <rect x="14" y="3" width="4" height="6" fill="#42a5f5"/>
    </svg>`,
    // ===== LINE CHART =====
    line: `
    <svg viewBox="0 0 24 24">
      <polyline points="2,18 6,10 10,14 14,6 18,12 22,4"
                fill="none"
                stroke="#1e88e5"
                stroke-width="2"/>
    </svg>`,

    // ===== AREA CHART =====
    area: `
    <svg viewBox="0 0 24 24">
      <polygon points="2,18 6,10 10,14 14,6 18,12 22,4 22,18 2,18"
               fill="#1e88e5" fill-opacity="0.5"/>
      <polyline points="2,18 6,10 10,14 14,6 18,12 22,4"
                fill="none"
                stroke="#1e88e5"
                stroke-width="2"/>
    </svg>`,

    // ===== STACKED AREA CHART =====
    stackedArea: `
    <svg viewBox="0 0 24 24">
      <polygon points="2,18 6,12 10,16 14,8 18,14 22,6 22,18 2,18"
               fill="#1565c0" fill-opacity="0.5"/>
      <polygon points="2,18 6,14 10,18 14,10 18,16 22,8 22,18 2,18"
               fill="#1e88e5" fill-opacity="0.5"/>
      <polyline points="2,18 6,12 10,16 14,8 18,14 22,6"
                fill="none"
                stroke="#1e88e5"
                stroke-width="2"/>
    </svg>`,

    // ===== PIE CHART =====
    pie: `
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">

  <!-- DEFINITIONS -->
  <defs>
    <linearGradient id="blueGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0d47a1"/>
      <stop offset="100%" stop-color="#1976d2"/>
    </linearGradient>

    <linearGradient id="blueGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1565c0"/>
      <stop offset="100%" stop-color="#42a5f5"/>
    </linearGradient>

    <linearGradient id="blueGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1e88e5"/>
      <stop offset="100%" stop-color="#90caf9"/>
    </linearGradient>
  </defs>
  <path d="M12 12 L12 2 A10 10 0 0 1 21.5 15 Z"
        fill="url(#blueGrad1)"/>
  <path d="M12 12 L21.5 15 A10 10 0 0 1 7 21 Z"
        fill="url(#blueGrad2)"/>
  <path d="M12 12 L7 21 A10 10 0 0 1 12 2 Z"
        fill="url(#blueGrad3)"/>

</svg>
`,
  };

  /* ================= SVG RETURN (SANITIZED) ================= */
  getChartSvg(type?: string): SafeHtml {
    if (!type) return '';
    const svg = this.chartSvgMap[type] || '';
    return this.sanitizer.bypassSecurityTrustHtml(svg);
  }

  /* ================= HELPERS ================= */
  removeChart(id: number): void {
    this.canvasCharts = this.canvasCharts.filter(c => c.id !== id);
  }

  /* ================= FILE UPLOAD (UNCHANGED) ================= */
  uploadFile(file: File, progressCallback: (v: number) => void): Promise<any[]> {
    return new Promise((resolve, reject) => {
      if (!file) return reject('No file selected');
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        progressCallback(progress);
        if (progress >= 100) {
          clearInterval(interval);
          this.readFile(file).then(resolve).catch(reject);
        }
      }, 300);
    });
  }

  readFile(file: File): Promise<any[]> {
    return new Promise((resolve, reject) => {
      if (file.name.toLowerCase().endsWith('.json')) {
        const reader = new FileReader();
        reader.onload = e => {
          try {
            resolve(JSON.parse((e.target as any).result));
          } catch {
            reject('Invalid JSON');
          }
        };
        reader.readAsText(file);
      } else {
        const reader = new FileReader();
        reader.onload = e => {
          const wb = XLSX.read((e.target as any).result, { type: 'binary' });
          const sheet = wb.Sheets[wb.SheetNames[0]];
          resolve(XLSX.utils.sheet_to_json(sheet));
        };
        reader.readAsBinaryString(file);
      }
    });
  }

  /* ================= DYNAMIC GRAPH GENERATION ================= */
  generateDynamicGraph(item: ChartItem): SafeHtml {
    if (!item.data || item.data.length === 0) {
      return this.getChartSvg(item.type); // Fallback to icon
    }

    const req = this.getChartRequirements(item.type);
    const width = item.width || 400; // Increased default width
    const height = item.height || 300; // Increased default height
    const padding = 70; // Increased padding for larger labels and axes
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;

    let labels: string[] = [];
    let values: number[] = [];

    // Colors
    const primaryColor = '#1a73e8';
    const secondaryColor = '#8ab4f8';
    const axisColor = '#5f6368';
    const gridColor = '#f1f3f4';
    const textColor = '#3c4043';

    // Aggregation Logic
    if (item.type === 'stackedBar' || item.type === 'stackedColumn') {
      const isBar = item.type === 'stackedBar';
      const categoryField = isBar ? item.yField : item.xField;
      const groupField = isBar ? item.xField : item.yField;

      if (categoryField && groupField && item.data) {
        const categories = [...new Set(item.data.map(d => String(d[categoryField] || 'N/A')))].slice(0, 8);
        const groups = [...new Set(item.data.map(d => String(d[groupField] || 'N/A')))];

        const datasets = groups.map((g, idx) => {
          const palette = ['#1a73e8', '#34a853', '#fbbc05', '#ea4335', '#46bdc6', '#ff6d01'];
          return {
            label: g,
            data: categories.map(c => {
              return item.data!.filter(d => String(d[categoryField]) === c && String(d[groupField]) === g).length;
            }),
            backgroundColor: palette[idx % palette.length],
            borderRadius: 4
          };
        });

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        new Chart(canvas, {
          type: 'bar',
          data: {
            labels: categories,
            datasets: datasets
          },
          options: {
            indexAxis: isBar ? 'y' : 'x',
            responsive: false,
            animation: false,
            plugins: {
              legend: { display: true, position: 'top', labels: { font: { size: 10, weight: 500 }, color: 'navy' } },
              tooltip: {
                enabled: true,
                backgroundColor: 'rgba(10, 37, 64, 0.9)',
                titleFont: { size: 14, weight: 'bold' },
                bodyFont: { size: 12 },
                padding: 10,
                displayColors: true
              },
              title: {
                display: true,
                text: item.name,
                color: 'navy',
                font: { size: 18, weight: 'bold', family: 'Inter' }
              }
            },
            scales: {
              x: { stacked: true, grid: { display: false }, ticks: { font: { size: 12, weight: 500 }, color: 'navy' } },
              y: { stacked: true, grid: { display: true, color: '#f1f3f4' }, ticks: { font: { size: 12, weight: 500 }, color: 'navy' } }
            }
          }
        });

        const dataUrl = canvas.toDataURL();
        return this.sanitizer.bypassSecurityTrustHtml(`
          <div style="width: 100%; height: 100%; min-width: 400px; min-height: 300px; display: flex; align-items: center; justify-content: center;">
            <img src="${dataUrl}" style="max-width: 100%; max-height: 100%; object-fit: contain;" />
          </div>
        `);
      }
    }

    if (item.type === 'bar' || item.type === 'column') {
      const isBar = item.type === 'bar';
      const dimField = isBar ? item.yField : item.xField;
      if (dimField && item.data) {
        const counts: Record<string, number> = {};
        item.data.forEach(d => {
          const val = String(d[dimField] || 'N/A');
          counts[val] = (counts[val] || 0) + 1;
        });
        labels = Object.keys(counts).slice(0, 10);
        values = labels.map(l => counts[l]);

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        new Chart(canvas, {
          type: 'bar',
          data: {
            labels: labels,
            datasets: [{
              label: item.name,
              data: values,
              backgroundColor: '#1a73e8',
              hoverBackgroundColor: '#0d47a1',
              borderRadius: 6,
              borderSkipped: false,
            }]
          },
          options: {
            indexAxis: isBar ? 'y' : 'x',
            responsive: false,
            animation: false,
            plugins: {
              legend: { display: false },
              tooltip: {
                enabled: true,
                backgroundColor: 'rgba(10, 37, 64, 0.9)',
                titleFont: { size: 14, weight: 'bold' },
                bodyFont: { size: 12 },
                padding: 10
              },
              title: {
                display: true,
                text: item.name,
                color: 'navy',
                font: { size: 18, weight: 'bold', family: 'Inter' }
              }
            },
            scales: {
              x: {
                grid: { display: !isBar, color: '#f1f3f4' },
                ticks: { font: { size: 14, weight: 500 }, color: 'navy' },
                beginAtZero: true
              },
              y: {
                grid: { display: isBar, color: '#f1f3f4' },
                ticks: { font: { size: 14, weight: 500 }, color: 'navy' }
              }
            }
          }
        });

        const dataUrl = canvas.toDataURL();
        return this.sanitizer.bypassSecurityTrustHtml(`
          <div style="width: 100%; height: 100%; min-width: 400px; min-height: 300px; display: flex; align-items: center; justify-content: center;">
            <img src="${dataUrl}" style="max-width: 100%; max-height: 100%; object-fit: contain;" />
          </div>
        `);
      }
    } else if (item.type === 'pie') {
      const dimField = item.xField || '';
      const valField = item.yField || '';
      if (dimField && valField) {
        labels = item.data.slice(0, 8).map(d => String(d[dimField] || ''));
        values = item.data.slice(0, 8).map(d => {
          const v = parseFloat(d[valField]);
          return isNaN(v) ? 0 : v;
        });
      }
    } else {
      const xF = item.xField || '';
      const yF = item.yField || '';
      if (xF && yF) {
        labels = item.data.slice(0, 8).map(d => String(d[xF] || ''));
        values = item.data.slice(0, 8).map(d => {
          const v = parseFloat(d[yF]);
          return isNaN(v) ? 0 : v;
        });
      }
    }

    if (labels.length === 0) return this.getChartSvg(item.type);

    const maxVal = Math.max(...values, 1);
    const niceMax = Math.ceil(maxVal / 10) * 10; // Simple rounding for grid
    let svgContent = '';

    // Add Grid Lines (Horizontal for Column/Line, Vertical for Bar)
    if (item.type === 'column' || item.type === 'stackedColumn' || item.type === 'line' || item.type === 'area') {
      for (let i = 0; i <= 5; i++) {
        const gy = height - padding - (i / 5) * chartHeight;
        svgContent += `<line x1="${padding}" y1="${gy}" x2="${width - padding}" y2="${gy}" stroke="${gridColor}" stroke-width="1" />`;
        svgContent += `<text x="${padding - 10}" y="${gy}" text-anchor="end" font-size="12" fill="${axisColor}" alignment-baseline="middle">${Math.round((i / 5) * maxVal)}</text>`;
      }
    } else if (item.type === 'bar' || item.type === 'stackedBar') {
      for (let i = 0; i <= 5; i++) {
        const gx = padding + (i / 5) * chartWidth;
        svgContent += `<line x1="${gx}" y1="${padding}" x2="${gx}" y2="${height - padding}" stroke="${gridColor}" stroke-width="1" />`;
        svgContent += `<text x="${gx}" y="${height - padding + 20}" text-anchor="middle" font-size="12" fill="${axisColor}">${Math.round((i / 5) * maxVal)}</text>`;
      }
    }

    if (item.type === 'bar' || item.type === 'stackedBar') {
      const barHeight = chartHeight / labels.length;
      values.forEach((v, i) => {
        const barWidth = (v / maxVal) * chartWidth;
        const ly = padding + i * barHeight + barHeight / 2;
        svgContent += `
          <rect x="${padding}" y="${padding + i * barHeight + 8}" width="${barWidth}" height="${barHeight - 16}" fill="${primaryColor}" rx="4" />
          <text x="${padding - 10}" y="${ly}" text-anchor="end" font-size="13" font-weight="500" fill="${textColor}" alignment-baseline="middle">${labels[i]}</text>
          <text x="${padding + barWidth + 10}" y="${ly}" font-size="12" font-weight="600" fill="${primaryColor}" alignment-baseline="middle">${v}</text>
        `;
      });
    } else if (item.type === 'column' || item.type === 'stackedColumn') {
      const barWidth = chartWidth / labels.length;
      values.forEach((v, i) => {
        const barHeightValue = (v / maxVal) * chartHeight;
        const lx = padding + i * barWidth + barWidth / 2;
        svgContent += `
          <rect x="${padding + i * barWidth + 10}" y="${height - padding - barHeightValue}" width="${barWidth - 20}" height="${barHeightValue}" fill="${primaryColor}" rx="4" />
          <text x="${lx}" y="${height - padding + 25}" text-anchor="middle" font-size="13" font-weight="500" fill="${textColor}" transform="rotate(-20, ${lx}, ${height - padding + 25})">${labels[i]}</text>
        `;
      });
    } else if (item.type === 'line' || item.type === 'area' || item.type === 'stackedArea') {
      const step = chartWidth / (labels.length - 1 || 1);
      let points = '';
      values.forEach((v, i) => {
        const px = padding + i * step;
        const py = height - padding - (v / maxVal) * chartHeight;
        points += `${px},${py} `;
        svgContent += `<circle cx="${px}" cy="${py}" r="5" fill="${primaryColor}" />`;
      });

      if (item.type === 'line') {
        svgContent += `<polyline points="${points}" fill="none" stroke="${primaryColor}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />`;
      } else {
        const fillPoints = `${padding},${height - padding} ${points} ${padding + (labels.length - 1) * step},${height - padding}`;
        svgContent += `<polygon points="${fillPoints}" fill="${primaryColor}" fill-opacity="0.15" />`;
        svgContent += `<polyline points="${points}" fill="none" stroke="${primaryColor}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />`;
      }

      labels.forEach((l, i) => {
        const px = padding + i * step;
        svgContent += `<text x="${px}" y="${height - padding + 25}" text-anchor="middle" font-size="13" font-weight="500" fill="${textColor}" transform="rotate(-20, ${px}, ${height - padding + 25})">${l}</text>`;
      });
    } else if (item.type === 'pie') {
      const radius = Math.min(chartWidth, chartHeight) / 2.2;
      const centerX = width / 2;
      const centerY = height / 2;
      let startAngle = 0;
      const total = values.reduce((a, b) => a + b, 0) || 1;

      values.forEach((v, i) => {
        const sliceAngle = (v / total) * 360;
        const endAngle = startAngle + sliceAngle;
        const x1 = centerX + radius * Math.cos(Math.PI * (startAngle - 90) / 180);
        const y1 = centerY + radius * Math.sin(Math.PI * (startAngle - 90) / 180);
        const x2 = centerX + radius * Math.cos(Math.PI * (endAngle - 90) / 180);
        const y2 = centerY + radius * Math.sin(Math.PI * (endAngle - 90) / 180);
        const largeArc = sliceAngle > 180 ? 1 : 0;
        const d = `M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;

        const palette = ['#4285f4', '#34a853', '#fbbc05', '#ea4335', '#46bdc6', '#ff6d01', '#673ab7', '#9c27b0'];
        const color = palette[i % palette.length];

        svgContent += `<path d="${d}" fill="${color}" stroke="#fff" stroke-width="2" />`;

        const midAngle = startAngle + sliceAngle / 2;
        const labelRadius = radius * 1.3;
        const tx = centerX + labelRadius * Math.cos(Math.PI * (midAngle - 90) / 180);
        const ty = centerY + labelRadius * Math.sin(Math.PI * (midAngle - 90) / 180);

        if (sliceAngle > 15) {
          svgContent += `
            <text x="${tx}" y="${ty}" text-anchor="middle" font-size="12" font-weight="600" fill="${textColor}">${labels[i]}</text>
            <text x="${tx}" y="${ty + 14}" text-anchor="middle" font-size="11" fill="${axisColor}">${Math.round((v / total) * 100)}%</text>
          `;
        }
        startAngle = endAngle;
      });
    }

    const svg = `
      <svg width="100%" height="100%" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" style="background: #fff;">
        <rect width="100%" height="100%" fill="#ffffff" rx="8" />
        <text x="${width / 2}" y="35" text-anchor="middle" font-weight="700" font-size="16" fill="${textColor}" font-family="Inter, sans-serif">${item.name}</text>
        ${svgContent}
        <!-- Main Axes Lines -->
        <line x1="${padding}" y1="${padding}" x2="${padding}" y2="${height - padding}" stroke="${axisColor}" stroke-width="2" stroke-linecap="round" />
        <line x1="${padding}" y1="${height - padding}" x2="${width - padding}" y2="${height - padding}" stroke="${axisColor}" stroke-width="2" stroke-linecap="round" />
      </svg>
    `;

    return this.sanitizer.bypassSecurityTrustHtml(svg);
  }
}
