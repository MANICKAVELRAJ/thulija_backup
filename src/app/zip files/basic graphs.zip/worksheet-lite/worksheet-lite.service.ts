import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as XLSX from 'xlsx';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs';

/* ================= CHART ================= */
export interface ChartItem {
  id: number;
  name: string;
  type: string;
  image?: string;
  x?: number;
  y?: number;
  zIndex?: number;
  width?: number;
  height?: number;
  isXYEnabled?: boolean;
  /* ===== DATA BINDING ===== */
  /* 🔥 DATA */
  tableId?: number;        // 🔥 ADD THIS
  tableName?: string;      // appendixe
  fields?: string[];
  data?: any[];
  valueField?: string
  xField?: string;
  yField?: string;


  xFieldId?: number;
  yFieldId?: number;

  xFieldValue?: string;
  yFieldValue?: string;
  realGraphSvg?: SafeHtml; // 🔥 Dynamic SVG
}

/* ================= CHART REQUIREMENTS ================= */
export interface ChartRequirements {
  selectableX: boolean;
  selectableY: boolean;
  xLabel: string;
  yLabel: string;
}
/* ================= PAGE ================= */
export interface PageItem {
  id: number;
  page_name: string;
  table_name: string;
}


@Injectable({ providedIn: 'root' })
export class WorksheetLiteService {

  /* ================= DATA ================= */
  chartTypes: ChartItem[] = [];
  canvasCharts: ChartItem[] = [];

  /* ================= WORKFLOW ================= */
  private workflowFieldsSubject = new BehaviorSubject<string[]>([]);
  workflowFields$ = this.workflowFieldsSubject.asObservable();

  /* ================= FIELDS.JSON ================= */
  private fieldsSubject = new BehaviorSubject<any[]>([]);
  fields$ = this.fieldsSubject.asObservable();

  get allFields(): any[] {
    return this.fieldsSubject.value;
  }

  /* ================= CANVAS ================= */
  nextId = 1000;
  zIndexCounter = 10;

  canvasEl!: HTMLElement;
  movingIndex: number | null = null;
  offsetX = 0;
  offsetY = 0;

  chartRequirementsMap: Record<string, ChartRequirements> = {
    bar: { selectableX: false, selectableY: true, xLabel: 'Count', yLabel: 'Field' },
    column: { selectableX: true, selectableY: false, xLabel: 'Field', yLabel: 'Count' },
    line: { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' },
    area: { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' },
    pie: { selectableX: true, selectableY: true, xLabel: 'Category', yLabel: 'Value' },
    stackedBar: { selectableX: false, selectableY: true, xLabel: 'Count', yLabel: 'Field' },
    stackedColumn: { selectableX: true, selectableY: false, xLabel: 'Field', yLabel: 'Count' },
    stackedArea: { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' },
  };

  getChartRequirements(type: string): ChartRequirements {
    return this.chartRequirementsMap[type] || { selectableX: true, selectableY: true, xLabel: 'X Field', yLabel: 'Y Field' };
  }

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer
  ) {
    this.loadWorkflow();
    this.loadFields();
    this.loadPages();
  }

  /* ================= INIT ================= */
  initCanvas(el: HTMLElement): void {
    this.canvasEl = el;
  }
  /* ================= LOAD FIELDS.JSON ================= */
  loadFields(): void {
    this.http.get<any[]>('assets/fields.json')
      .subscribe(res => {
        if (Array.isArray(res)) {
          this.fieldsSubject.next(res);
          console.log('Fields.json:', res);
        } else {
          this.fieldsSubject.next([]);
        }
      });
  }

  /* ================= LOAD PAGES.JSON ================= */
  private pagesSubject = new BehaviorSubject<PageItem[]>([]);
  pages$ = this.pagesSubject.asObservable();

  loadPages(): void {
    this.http.get<PageItem[]>('assets/pages.json')
      .subscribe(res => {
        if (Array.isArray(res) && res.length > 0) {
          this.pagesSubject.next(res);
          console.log('Pages.json loaded:', res);
        } else {
          this.pagesSubject.next([]);
        }
      });
  }


  /* ================= LOAD CHARTS ================= */
  loadCharts(): Promise<ChartItem[]> {
    return this.http
      .get<ChartItem[]>('assets/chart.json')
      .toPromise()
      .then(res => {
        this.chartTypes = res || [];
        return this.chartTypes;
      });
  }

  /* ================= LOAD WORKFLOW (FIXED) ================= */
  loadWorkflow(): void {
    this.http.get<any[]>('assets/workflowprocess.json')
      .subscribe(res => {

        if (!Array.isArray(res) || res.length === 0) {
          this.workflowFieldsSubject.next([]);
          return;
        }

        // 🔥 extract keys from first object
        const fields = Object.keys(res[0]);

        this.workflowFieldsSubject.next(fields);
        console.log('Workflow Fields:', fields);
      });
  }
  /* ================= DROP ================= */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    if (event.previousContainer.id !== 'chartList') return;

    const draggedChart = event.item.data as ChartItem;
    const rect = this.canvasEl.getBoundingClientRect();
    const mouse = event.event as MouseEvent;

    const width = 180;
    const height = 140;

    let x = mouse.clientX - rect.left - width / 2;
    let y = mouse.clientY - rect.top - height / 2;

    [x, y] = this.findFreePosition(x, y, width, height);

    this.canvasCharts.push({
      ...draggedChart,
      id: this.nextId++,
      x,
      y,
      width,
      height,
      zIndex: ++this.zIndexCounter
    });
  }


  /* ================= OVERLAP ================= */
  findFreePosition(
    x: number,
    y: number,
    width: number,
    height: number,
    ignoreIndex: number | null = null
  ): [number, number] {

    const padding = 16;

    x = Math.max(0, Math.min(x, this.canvasEl.clientWidth - width));
    y = Math.max(0, Math.min(y, this.canvasEl.clientHeight - height));

    for (let i = 0; i < 200; i++) {
      let overlap = false;

      for (let j = 0; j < this.canvasCharts.length; j++) {
        if (ignoreIndex === j) continue;

        const c = this.canvasCharts[j];
        const hit = !(
          x + width + padding < c.x! ||
          x > c.x! + c.width! + padding ||
          y + height + padding < c.y! ||
          y > c.y! + c.height! + padding
        );

        if (hit) {
          overlap = true;
          x += padding;
          y += padding;
          break;
        }
      }
      if (!overlap) break;
    }
    return [x, y];
  }

  /* ================= MOVE ================= */
  startMove(event: MouseEvent, index: number): void {
    this.movingIndex = index;
    const item = this.canvasCharts[index];
    item.zIndex = ++this.zIndexCounter;
    this.offsetX = event.offsetX;
    this.offsetY = event.offsetY;
  }

  moveItem(event: MouseEvent): void {
    if (this.movingIndex === null) return;

    const rect = this.canvasEl.getBoundingClientRect();
    const item = this.canvasCharts[this.movingIndex];

    item.x = Math.max(
      0,
      Math.min(
        event.clientX - rect.left - this.offsetX,
        this.canvasEl.clientWidth - item.width!
      )
    );

    item.y = Math.max(
      0,
      Math.min(
        event.clientY - rect.top - this.offsetY,
        this.canvasEl.clientHeight - item.height!
      )
    );
  }

  stopMove(): void {
    if (this.movingIndex === null) return;

    const item = this.canvasCharts[this.movingIndex];
    const [x, y] = this.findFreePosition(
      item.x!,
      item.y!,
      item.width!,
      item.height!,
      this.movingIndex
    );

    item.x = x;
    item.y = y;
    this.movingIndex = null;
  }

  /* ================= SVG MAP ================= */
  chartSvgMap: Record<string, string> = {

    bar: `
    <svg viewBox="0 0 24 24">
      <rect x="2" y="2" width="21" height="6" fill="#1e88e5"/>
      <rect x="2" y="10" width="15" height="6" fill="#1e88e5"/>
      <rect x="2" y="18" width="9" height="6" fill="#1e88e5"/>
    </svg>
`,

    column: `
    <svg viewBox="0 0 24 24">
      <rect x="2" y="3" width="6" height="21" fill="#1e88e5"/>
      <rect x="10" y="9" width="6" height="15" fill="#1e88e5"/>
      <rect x="18" y="15" width="6" height="9" fill="#1e88e5"/>
    </svg>
`,

    stackedBar: `
    <svg viewBox="0 0 24 24">
      <rect x="0" y="2" width="5" height="4" fill="#1565c0"/>
      <rect x="5" y="2" width="6" height="4" fill="#1e88e5"/>
      <rect x="11" y="2" width="7" height="4" fill="#42a5f5"/>

      <rect x="0" y="8" width="10" height="4" fill="#1565c0"/>
      <rect x="10" y="8" width="8" height="4" fill="#1e88e5"/>
      <rect x="18" y="8" width="6" height="4" fill="#42a5f5"/>

      <rect x="0" y="14" width="6" height="4" fill="#1565c0"/>
      <rect x="6" y="14" width="9" height="4" fill="#1e88e5"/>
      <rect x="15" y="14" width="6" height="4" fill="#42a5f5"/>
  </svg>`,

    stackedColumn: `
    <svg viewBox="0 0 24 24">
      <rect x="2" y="19" width="4" height="5" fill="#1565c0"/>
      <rect x="2" y="13" width="4" height="6" fill="#1e88e5"/>
      <rect x="2" y="6" width="4" height="7" fill="#42a5f5"/>

      <rect x="8" y="14" width="4" height="10" fill="#1565c0"/>
      <rect x="8" y="6" width="4" height="8" fill="#1e88e5"/>
      <rect x="8" y="0" width="4" height="6" fill="#42a5f5"/>

      <rect x="14" y="18" width="4" height="6" fill="#1565c0"/>
      <rect x="14" y="9" width="4" height="9" fill="#1e88e5"/>
      <rect x="14" y="3" width="4" height="6" fill="#42a5f5"/>
    </svg>`,
    // ===== LINE CHART =====
    line: `
    <svg viewBox="0 0 24 24">
      <polyline points="2,18 6,10 10,14 14,6 18,12 22,4"
                fill="none"
                stroke="#1e88e5"
                stroke-width="2"/>
    </svg>`,

    // ===== AREA CHART =====
    area: `
    <svg viewBox="0 0 24 24">
      <polygon points="2,18 6,10 10,14 14,6 18,12 22,4 22,18 2,18"
               fill="#1e88e5" fill-opacity="0.5"/>
      <polyline points="2,18 6,10 10,14 14,6 18,12 22,4"
                fill="none"
                stroke="#1e88e5"
                stroke-width="2"/>
    </svg>`,

    // ===== STACKED AREA CHART =====
    stackedArea: `
    <svg viewBox="0 0 24 24">
      <polygon points="2,18 6,12 10,16 14,8 18,14 22,6 22,18 2,18"
               fill="#1565c0" fill-opacity="0.5"/>
      <polygon points="2,18 6,14 10,18 14,10 18,16 22,8 22,18 2,18"
               fill="#1e88e5" fill-opacity="0.5"/>
      <polyline points="2,18 6,12 10,16 14,8 18,14 22,6"
                fill="none"
                stroke="#1e88e5"
                stroke-width="2"/>
    </svg>`,

    // ===== PIE CHART =====
    pie: `
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">

  <!-- DEFINITIONS -->
  <defs>
    <linearGradient id="blueGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0d47a1"/>
      <stop offset="100%" stop-color="#1976d2"/>
    </linearGradient>

    <linearGradient id="blueGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1565c0"/>
      <stop offset="100%" stop-color="#42a5f5"/>
    </linearGradient>

    <linearGradient id="blueGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1e88e5"/>
      <stop offset="100%" stop-color="#90caf9"/>
    </linearGradient>
  </defs>
  <path d="M12 12 L12 2 A10 10 0 0 1 21.5 15 Z"
        fill="url(#blueGrad1)"/>
  <path d="M12 12 L21.5 15 A10 10 0 0 1 7 21 Z"
        fill="url(#blueGrad2)"/>
  <path d="M12 12 L7 21 A10 10 0 0 1 12 2 Z"
        fill="url(#blueGrad3)"/>

</svg>
`,
  };

  /* ================= SVG RETURN (SANITIZED) ================= */
  getChartSvg(type?: string): SafeHtml {
    if (!type) return '';
    const svg = this.chartSvgMap[type] || '';
    return this.sanitizer.bypassSecurityTrustHtml(svg);
  }

  /* ================= HELPERS ================= */
  removeChart(id: number): void {
    this.canvasCharts = this.canvasCharts.filter(c => c.id !== id);
  }

  /* ================= FILE UPLOAD (UNCHANGED) ================= */
  uploadFile(file: File, progressCallback: (v: number) => void): Promise<any[]> {
    return new Promise((resolve, reject) => {
      if (!file) return reject('No file selected');
      let progress = 0;
      const interval = setInterval(() => {
        progress += 10;
        progressCallback(progress);
        if (progress >= 100) {
          clearInterval(interval);
          this.readFile(file).then(resolve).catch(reject);
        }
      }, 300);
    });
  }

  readFile(file: File): Promise<any[]> {
    return new Promise((resolve, reject) => {
      if (file.name.toLowerCase().endsWith('.json')) {
        const reader = new FileReader();
        reader.onload = e => {
          try {
            resolve(JSON.parse((e.target as any).result));
          } catch {
            reject('Invalid JSON');
          }
        };
        reader.readAsText(file);
      } else {
        const reader = new FileReader();
        reader.onload = e => {
          const wb = XLSX.read((e.target as any).result, { type: 'binary' });
          const sheet = wb.Sheets[wb.SheetNames[0]];
          resolve(XLSX.utils.sheet_to_json(sheet));
        };
        reader.readAsBinaryString(file);
      }
    });
  }

  /* ================= DYNAMIC GRAPH GENERATION ================= */
  generateDynamicGraph(item: ChartItem): SafeHtml {
    if (!item.data || item.data.length === 0) {
      return this.getChartSvg(item.type); // Fallback to icon
    }

    const req = this.getChartRequirements(item.type);
    const width = item.width || 300;
    const height = item.height || 200;
    const padding = 50; // Increased padding for labels
    const chartWidth = width - padding * 1.5;
    const chartHeight = height - padding * 1.5;

    let labels: string[] = [];
    let values: number[] = [];

    // Aggregation Logic
    if (item.type === 'bar' || item.type === 'stackedBar') {
      // Index on Y, value on X
      const dimField = item.yField || '';
      if (dimField) {
        const counts: Record<string, number> = {};
        item.data.forEach(d => {
          const val = String(d[dimField] || 'N/A');
          counts[val] = (counts[val] || 0) + 1;
        });
        labels = Object.keys(counts).slice(0, 10);
        values = labels.map(l => counts[l]);
      }
    } else if (item.type === 'column' || item.type === 'stackedColumn') {
      // Index on X, value on Y
      const dimField = item.xField || '';
      if (dimField) {
        const counts: Record<string, number> = {};
        item.data.forEach(d => {
          const val = String(d[dimField] || 'N/A');
          counts[val] = (counts[val] || 0) + 1;
        });
        labels = Object.keys(counts).slice(0, 10);
        values = labels.map(l => counts[l]);
      }
    } else if (item.type === 'pie') {
      const dimField = item.xField || '';
      const valField = item.yField || '';
      if (dimField && valField) {
        labels = item.data.slice(0, 10).map(d => String(d[dimField] || ''));
        values = item.data.slice(0, 10).map(d => {
          const v = parseFloat(d[valField]);
          return isNaN(v) ? 0 : v;
        });
      }
    } else {
      // Default (Line, Area, etc.)
      const xF = item.xField || '';
      const yF = item.yField || '';
      if (xF && yF) {
        labels = item.data.slice(0, 10).map(d => String(d[xF] || ''));
        values = item.data.slice(0, 10).map(d => {
          const v = parseFloat(d[yF]);
          return isNaN(v) ? 0 : v;
        });
      }
    }

    if (labels.length === 0) return this.getChartSvg(item.type);

    const maxVal = Math.max(...values, 1);
    let svgContent = '';

    if (item.type === 'bar' || item.type === 'stackedBar') {
      const barHeight = chartHeight / labels.length;
      values.forEach((v, i) => {
        const barWidth = (v / maxVal) * chartWidth;
        const ly = padding + i * barHeight + barHeight / 2;
        svgContent += `
          <rect x="${padding}" y="${padding + i * barHeight + 5}" width="${barWidth}" height="${barHeight - 10}" fill="#1e88e5" rx="2" />
          <text x="${padding - 5}" y="${ly}" text-anchor="end" font-size="9" fill="#444" alignment-baseline="middle">${labels[i]}</text>
          <text x="${padding + barWidth + 5}" y="${ly}" font-size="9" fill="#666" alignment-baseline="middle">${v}</text>
        `;
      });
    } else if (item.type === 'column' || item.type === 'stackedColumn') {
      const barWidth = chartWidth / labels.length;
      values.forEach((v, i) => {
        const barHeightValue = (v / maxVal) * chartHeight;
        const lx = padding + i * barWidth + barWidth / 2;
        svgContent += `
          <rect x="${padding + i * barWidth + 5}" y="${height - padding - barHeightValue}" width="${barWidth - 10}" height="${barHeightValue}" fill="#1e88e5" rx="2" />
          <text x="${lx}" y="${height - padding + 15}" text-anchor="middle" font-size="9" fill="#444" transform="rotate(15, ${lx}, ${height - padding + 15})">${labels[i]}</text>
        `;
      });
    } else if (item.type === 'line' || item.type === 'area' || item.type === 'stackedArea') {
      const step = chartWidth / (labels.length - 1 || 1);
      let points = '';
      values.forEach((v, i) => {
        const px = padding + i * step;
        const py = height - padding - (v / maxVal) * chartHeight;
        points += `${px},${py} `;
        svgContent += `<circle cx="${px}" cy="${py}" r="3" fill="#1e88e5" />`;
      });

      if (item.type === 'line') {
        svgContent += `<polyline points="${points}" fill="none" stroke="#1e88e5" stroke-width="2" />`;
      } else {
        const fillPoints = `${padding},${height - padding} ${points} ${padding + (labels.length - 1) * step},${height - padding}`;
        svgContent += `<polygon points="${fillPoints}" fill="#1e88e5" fill-opacity="0.2" />`;
        svgContent += `<polyline points="${points}" fill="none" stroke="#1e88e5" stroke-width="2" />`;
      }

      labels.forEach((l, i) => {
        const px = padding + i * step;
        svgContent += `<text x="${px}" y="${height - padding + 15}" text-anchor="middle" font-size="9" fill="#444" transform="rotate(15, ${px}, ${height - padding + 15})">${l}</text>`;
      });
    } else if (item.type === 'pie') {
      const radius = Math.min(chartWidth, chartHeight) / 2;
      const centerX = padding + chartWidth / 2;
      const centerY = padding + chartHeight / 2;
      let startAngle = 0;
      const total = values.reduce((a, b) => a + b, 0) || 1;

      values.forEach((v, i) => {
        const sliceAngle = (v / total) * 360;
        const endAngle = startAngle + sliceAngle;
        const x1 = centerX + radius * Math.cos(Math.PI * (startAngle - 90) / 180);
        const y1 = centerY + radius * Math.sin(Math.PI * (startAngle - 90) / 180);
        const x2 = centerX + radius * Math.cos(Math.PI * (endAngle - 90) / 180);
        const y2 = centerY + radius * Math.sin(Math.PI * (endAngle - 90) / 180);
        const largeArc = sliceAngle > 180 ? 1 : 0;
        const d = `M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;
        const colors = ['#1565c0', '#1e88e5', '#42a5f5', '#90caf9', '#bbdefb', '#64b5f6', '#2196f3', '#1976d2', '#1565c0', '#0d47a1'];
        svgContent += `<path d="${d}" fill="${colors[i % colors.length]}" stroke="#fff" stroke-width="1" />`;

        // Labels for pie
        const midAngle = startAngle + sliceAngle / 2;
        const tx = centerX + (radius + 20) * Math.cos(Math.PI * (midAngle - 90) / 180);
        const ty = centerY + (radius + 20) * Math.sin(Math.PI * (midAngle - 90) / 180);
        if (sliceAngle > 10) {
          svgContent += `<text x="${tx}" y="${ty}" text-anchor="middle" font-size="8" fill="#666">${labels[i]}</text>`;
        }
        startAngle = endAngle;
      });
    }

    const svg = `
      <svg width="100%" height="100%" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="#fff" rx="4" />
        <text x="${width / 2}" y="20" text-anchor="middle" font-weight="bold" font-size="12" fill="#333">${item.name}</text>
        ${svgContent}
        <!-- Axes -->
        <line x1="${padding}" y1="${padding}" x2="${padding}" y2="${height - padding}" stroke="#eee" stroke-width="1" />
        <line x1="${padding}" y1="${height - padding}" x2="${width - padding}" y2="${height - padding}" stroke="#eee" stroke-width="1" />
      </svg>
    `;

    return this.sanitizer.bypassSecurityTrustHtml(svg);
  }
}
