import {
  Component,
  OnInit,
  AfterViewInit,
  HostListener
} from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { WorksheetLiteService, PageItem } from './worksheet-lite.service';
import { ChartItem, SmartFieldAnalyser, SmartAnalysis } from './chart-gen.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-worksheet-lite',
  templateUrl: './worksheet-lite.component.html',
  styleUrls: ['./worksheet-lite.component.css']
})
export class WorksheetLiteComponent implements OnInit, AfterViewInit {

  /* ===================== SIDEBAR ===================== */
  isSidebarCollapsed = false;

  /* ===================== FILE UPLOAD ===================== */
  uploadProgress = 0;
  isCustomDataUploaded = false;

  /* ===================== PROPERTY PANEL ===================== */
  propertyPanelOpen = false;
  selectedItem: ChartItem | null = null;
  editableItem: ChartItem | null = null;
  originalSnapshot: ChartItem | null = null;

  pages: PageItem[] = [];

  /* ===================== SMART FIELD LISTS ===================== */
  // Populated by SmartFieldAnalyser after table is chosen
  // These drive the categorized dropdowns in the property panel
  smartAnalysis: SmartAnalysis | null = null;
  labelFields: string[] = [];   // unique-per-row fields: column_name, property_name
  catFields: string[] = [];   // grouped/counted fields: data_type_id, hide, etc.
  numFields: string[] = [];   // numeric measure fields: display_width, etc.
  usableFields: string[] = [];   // all three combined for general dropdown

  chartRequirements: any = null;

  /* ===================== RESIZE STATE ===================== */
  private resizingIndex = -1;
  private resizeDirection = '';
  private resizeStartX = 0;
  private resizeStartY = 0;
  private resizeStartW = 0;
  private resizeStartH = 0;
  private resizeStartLeft = 0;
  private resizeStartTop = 0;

  readonly MIN_W = 180;
  readonly MIN_H = 140;

  constructor(
    public service: WorksheetLiteService,
    private snackBar: MatSnackBar
  ) { }

  /* ================================================================
     LIFECYCLE
  ================================================================ */
  ngOnInit(): void {
    this.service.loadCharts();
    this.service.loadWorkflow();

    this.service.fields$.subscribe(fields => {
      if (fields.length > 0) this.updateChartsWithNewData();
    });

    this.service.pages$.subscribe(pages => {
      this.pages = pages || [];
    });
  }

  ngAfterViewInit(): void {
    const canvas = document.querySelector('.worksheet') as HTMLElement;
    if (canvas) this.service.initCanvas(canvas);
  }

  /* ================================================================
     CANVAS DROP
  ================================================================ */
  dropOnCanvas(event: CdkDragDrop<any>): void {
    this.service.dropOnCanvas(event);
    const last = this.service.canvasCharts[this.service.canvasCharts.length - 1];
    if (last) this.openPropertyPanel(last);
  }

  /* ================================================================
     MOVE
  ================================================================ */
  startMove(event: MouseEvent, index: number): void {
    if ((event.target as HTMLElement).classList.contains('resize-handle')) return;
    this.service.startMove(event, index);
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    if (this.resizingIndex >= 0) this.doResize(event);
    else this.service.moveItem(event);
  }

  @HostListener('document:mouseup')
  onMouseUp(): void {
    if (this.resizingIndex >= 0) this.stopResize();
    else this.service.stopMove();
  }

  /* ================================================================
     RESIZE
  ================================================================ */
  startResize(event: MouseEvent, index: number, direction: string): void {
    event.preventDefault(); event.stopPropagation();
    const c = this.service.canvasCharts[index];
    this.resizingIndex = index;
    this.resizeDirection = direction;
    this.resizeStartX = event.clientX;
    this.resizeStartY = event.clientY;
    this.resizeStartW = c.width ?? this.MIN_W;
    this.resizeStartH = c.height ?? this.MIN_H;
    this.resizeStartLeft = c.x ?? 0;
    this.resizeStartTop = c.y ?? 0;
  }

  private doResize(event: MouseEvent): void {
    if (this.resizingIndex < 0) return;
    const c = this.service.canvasCharts[this.resizingIndex];
    const dx = event.clientX - this.resizeStartX;
    const dy = event.clientY - this.resizeStartY;
    const dir = this.resizeDirection;
    const maxW = this.service.canvasEl?.clientWidth ?? 9999;
    const maxH = this.service.canvasEl?.clientHeight ?? 9999;

    let newW = this.resizeStartW, newH = this.resizeStartH;
    let newX = this.resizeStartLeft, newY = this.resizeStartTop;

    if (dir.includes('e')) newW = Math.min(maxW - newX, Math.max(this.MIN_W, this.resizeStartW + dx));
    if (dir.includes('w')) { newX = Math.max(0, this.resizeStartLeft + dx); newW = Math.max(this.MIN_W, this.resizeStartLeft + this.resizeStartW - newX); }
    if (dir.includes('s')) newH = Math.min(maxH - newY, Math.max(this.MIN_H, this.resizeStartH + dy));
    if (dir.includes('n')) { newY = Math.max(0, this.resizeStartTop + dy); newH = Math.max(this.MIN_H, this.resizeStartTop + this.resizeStartH - newY); }

    c.width = Math.round(newW); c.height = Math.round(newH);
    c.x = Math.round(newX); c.y = Math.round(newY);
  }

  private stopResize(): void { this.resizingIndex = -1; this.resizeDirection = ''; }

  /* ================================================================
     PROPERTY PANEL OPEN
  ================================================================ */
  openPropertyPanel(chart: ChartItem): void {
    this.isCustomDataUploaded = false;
    this.selectedItem = chart;
    this.originalSnapshot = JSON.parse(JSON.stringify(chart));

    this.editableItem = {
      ...chart,
      x: Math.round(chart.x ?? 0),
      y: Math.round(chart.y ?? 0),
      width: Math.round(chart.width ?? this.MIN_W),
      height: Math.round(chart.height ?? this.MIN_H)
    };

    // If chart already has data (previously configured), re-analyse
    if (this.editableItem.data?.length) {
      this.runSmartAnalysis(this.editableItem.data);
    } else if (this.editableItem.tableId) {
      // Re-fetch data from stored tableId
      const page = this.pages.find(p => p.id === this.editableItem!.tableId);
      if (page) {
        const rows = this.service.allFields.filter(f => f.page_id == page.id);
        this.editableItem.data = rows;
        this.runSmartAnalysis(rows);
      }
    } else {
      this.clearSmartAnalysis();
    }

    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
    this.propertyPanelOpen = true;
  }

  /* ================================================================
     TABLE SELECT — core smart flow:
     1. Fetch rows for chosen page_id
     2. Run SmartFieldAnalyser on those rows
     3. Auto-populate X/Y fields based on chart type
     4. Force new editableItem reference so renderer detects change
  ================================================================ */
  onTableSelect(tableValue: string): void {
    const tableId = +tableValue;
    if (!this.editableItem || !tableId) return;

    const page = this.pages.find(p => p.id == tableId);
    if (!page) return;

    // Fetch rows for this page
    const rows = this.service.allFields.filter(f => f.page_id == page.id);

    // Run smart analysis on actual values
    const sa = SmartFieldAnalyser.analyse(rows);
    this.applySmartAnalysis(sa);

    // Auto-pick best fields for the chosen chart type
    const { autoX, autoY } = this.autoPickFields(this.editableItem.type, sa);

    // NEW object reference -> ChartRendererComponent ngOnChanges fires immediately
    this.editableItem = {
      ...this.editableItem,
      tableId: +page.id,
      tableName: page.table_name,
      data: rows,
      fields: sa.usableFields,    // only useful fields in dropdown
      isXYEnabled: true,
      xField: autoX,
      yField: autoY
    };

    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);

    this.snackBar.open(
      `Loaded ${rows.length} rows — ${sa.labelFields.length} label, ${sa.catFields.length} categorical, ${sa.numFields.length} numeric`,
      'OK', { duration: 3000, horizontalPosition: 'right' }
    );
  }

  /* ================================================================
     CHART TYPE CHANGE — re-pick best fields for new chart type
  ================================================================ */
  onChartTypeChange(newType: string): void {
    if (!this.editableItem) return;
    this.chartRequirements = this.service.getChartRequirements(newType);

    if (this.smartAnalysis) {
      const { autoX, autoY } = this.autoPickFields(newType, this.smartAnalysis);
      // New reference so renderer re-renders
      this.editableItem = { ...this.editableItem, type: newType, xField: autoX, yField: autoY };
    } else {
      this.editableItem = { ...this.editableItem, type: newType };
    }
  }

  /* ================================================================
     FIELD CHANGE — new reference triggers live preview
  ================================================================ */
  onXFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem = { ...this.editableItem, xField: fieldName };
    this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
  }

  onYFieldChange(fieldName: string): void {
    if (!this.editableItem) return;
    this.editableItem = { ...this.editableItem, yField: fieldName };
  }

  /* ================================================================
     SAVE — replaces array slot with new object -> ngOnChanges fires
  ================================================================ */
  saveChanges(): void {
    if (!this.selectedItem || !this.editableItem) return;
    const idx = this.service.canvasCharts.findIndex(c => c.id === this.selectedItem!.id);
    if (idx !== -1) {
      this.service.canvasCharts[idx] = { ...this.editableItem };
    }
    this.cleanupPropertyPanel();
  }

  /* ================================================================
     CANCEL — restore snapshot with new reference
  ================================================================ */
  cancelChanges(): void {
    if (this.selectedItem && this.originalSnapshot) {
      const idx = this.service.canvasCharts.findIndex(c => c.id === this.selectedItem!.id);
      if (idx !== -1) {
        this.service.canvasCharts[idx] = { ...this.originalSnapshot };
      }
    }
    this.cleanupPropertyPanel();
  }

  cleanupPropertyPanel(): void {
    this.propertyPanelOpen = false;
    this.selectedItem = null;
    this.editableItem = null;
    this.originalSnapshot = null;
    this.uploadProgress = 0;
    this.clearSmartAnalysis();
  }

  removeChart(id: number): void {
    this.service.removeChart(id);
    if (this.selectedItem?.id === id) this.cleanupPropertyPanel();
  }

  /* ================================================================
     SIZE CHANGE
  ================================================================ */
  onSizeChange(): void {
    if (!this.editableItem) return;
    if ((this.editableItem.width ?? 0) < this.MIN_W) this.editableItem.width = this.MIN_W;
    if ((this.editableItem.height ?? 0) < this.MIN_H) this.editableItem.height = this.MIN_H;
    const el = this.service.canvasEl;
    if (el) {
      const mw = el.clientWidth - (this.editableItem.x ?? 0);
      const mh = el.clientHeight - (this.editableItem.y ?? 0);
      if ((this.editableItem.width ?? 0) > mw) this.editableItem.width = mw;
      if ((this.editableItem.height ?? 0) > mh) this.editableItem.height = mh;
    }
  }

  checkOverlapLive(item: ChartItem): void {
    if (!item) return;
    const idx = this.service.canvasCharts.findIndex(c => c.id === item.id);
    if (idx === -1) return;
    const [nx, ny] = this.service.findFreePosition(
      item.x ?? 0, item.y ?? 0, item.width ?? 0, item.height ?? 0, idx
    );
    item.x = nx; item.y = ny;
  }

  /* ================================================================
     FILE UPLOAD
  ================================================================ */
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;
    const file = input.files[0];
    this.uploadProgress = 0;

    this.service.uploadFile(file, p => { this.uploadProgress = p; }).then(data => {
      this.isCustomDataUploaded = true;
      if (this.editableItem) {
        const sa = SmartFieldAnalyser.analyse(data);
        this.applySmartAnalysis(sa);
        const { autoX, autoY } = this.autoPickFields(this.editableItem.type, sa);
        this.editableItem = {
          ...this.editableItem,
          data: data,
          fields: sa.usableFields,
          isXYEnabled: true,
          xField: autoX,
          yField: autoY
        };
        this.chartRequirements = this.service.getChartRequirements(this.editableItem.type);
      }
      this.uploadProgress = 100;
      setTimeout(() => { this.uploadProgress = 0; }, 2000);
    });
  }

  /* ================================================================
     SIDEBAR
  ================================================================ */
  toggleSidebar(): void { this.isSidebarCollapsed = !this.isSidebarCollapsed; }

  /* ================================================================
     REAL-TIME DATA SYNC
  ================================================================ */
  updateChartsWithNewData(): void {
    this.service.canvasCharts.forEach(chart => {
      if (!chart.tableId) return;
      const nd = this.service.getFieldsByPageId(String(chart.tableId));
      if (nd?.length) chart.data = nd;
    });
  }

  /* ================================================================
     SMART FIELD HELPERS
  ================================================================ */

  /**
   * Run SmartFieldAnalyser and store results into component state.
   * Called whenever data rows change (table select, file upload, re-open panel).
   */
  private runSmartAnalysis(rows: any[]): void {
    const sa = SmartFieldAnalyser.analyse(rows);
    this.applySmartAnalysis(sa);
    if (this.editableItem) {
      this.editableItem.fields = sa.usableFields;
    }
  }

  private applySmartAnalysis(sa: SmartAnalysis): void {
    this.smartAnalysis = sa;
    this.labelFields = sa.labelFields;
    this.catFields = sa.catFields;
    this.numFields = sa.numFields;
    this.usableFields = sa.usableFields;
  }

  private clearSmartAnalysis(): void {
    this.smartAnalysis = null;
    this.labelFields = [];
    this.catFields = [];
    this.numFields = [];
    this.usableFields = [];
  }

  /**
   * Auto-pick the best X and Y fields for a given chart type
   * based on the smart analysis of the data.
   *
   * Chart type -> field strategy:
   *   bar / column / line / area:
   *     X = label field (column_name) -> each row = 1 bar with its name
   *     Y = numeric field (display_width) if available, else '' = count
   *
   *   pie:
   *     X = categorical field (data_type_id) -> few meaningful slices
   *     Y = '' (always count)
   *
   *   stacked bar/column/area:
   *     X = first categorical field
   *     Y = second categorical field (sub-group)
   */
  private autoPickFields(chartType: string, sa: SmartAnalysis): { autoX: string; autoY: string } {
    switch (chartType) {
      case 'bar':
      case 'column':
      case 'line':
      case 'area':
        return { autoX: sa.defaultX, autoY: sa.defaultY };

      case 'pie':
        return { autoX: sa.defaultCatX || sa.defaultX, autoY: '' };

      case 'stackedBar':
      case 'stackedColumn':
      case 'stackedArea':
        return {
          autoX: sa.defaultCatX || sa.defaultX,
          autoY: sa.catFields[1] || ''
        };

      default:
        return { autoX: sa.defaultX, autoY: sa.defaultY };
    }
  }

  /** Get field kind badge text for UI display */
  fieldKindBadge(fieldKey: string): string {
    if (this.labelFields.includes(fieldKey)) return 'Label';
    if (this.catFields.includes(fieldKey)) return 'Group';
    if (this.numFields.includes(fieldKey)) return 'Numeric';
    return '';
  }
}
